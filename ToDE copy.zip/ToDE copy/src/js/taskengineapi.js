/*
* Task Engine API List
*/
import qs from 'qs';

const env = process.env.NODE_ENV === 'production';

// 0. 获取任务列表
function axiosGetScenarioList(appId, fnSuccess) {
  const res = [
    {taskId: '123', taskName: '招行信诺回访', enabled: true }
  ];
  fnSuccess(res);
  // this.$axiosGet(`/api/task_engine/app?appid=${appId}&time=${time}`).then(res => fnSuccess(JSON.parse(res.data).msg));
}

// 1. 创建任务
function aioxsCreateScenario(appId, scenarioName, template, fnSuccess) {
  const time = Date.parse(new Date());
  const params = {
    appid: appId,
    template,
    scenarioName,
    method: 'POST',
  };
  if (env) {
    this.$axiosPost(`/api/task_engine/scenario?time=${time}`, qs.stringify(params)).then((res) => {
      fnSuccess(res.data);
    });
  } else {
    const fso = new ActiveXObject("Scripting.FileSystemObject"); 
    let f1 = fso.createtextfile('../mockdata/myjstest.txt', true);
  }
  
}

// 2. 删除任务
function axiosDeleteTask(appId, taskId, funSuccess) {
  console.log('axiosDeleteTask');
}

// 3. 修改任务详情
function axiosUpdateTaskDetail(appId, taskId, detailJson) {
  console.log('axiosUpdateTaskDetail');
}

// 4. 获取任务详情
function axiosGetScenarioDetail(scenarioid, fnSuccess) {
  const time = Date.parse(new Date());
  const params = {
    method: 'GET',
    scenarioid,
  };
  if (env) {
    this.$axiosPost(`/apitask_engine/scenario?time=${time}`, qs.stringify(params)).then(res => fnSuccess(JSON.parse(res.data.result.editingContent)));
  } else {
    // eslint-disable-next-line
    const mock = require('../mockdata/招商信诺回访.json');
    fnSuccess(mock);
  }
}

// 5. 获取意图列表
function axiosGetIntentsList(appId, fnSuccess) {
  const res = [
    { intentId: '001', intentTitle: '招商回访'},
    { intentId: '002', intentTitle: '意图1' },
    { intentId: '003', intentTitle: '意图2' },
    { intentId: '004', intentTitle: '意图3' },
  ];
  fnSuccess(res);
}

// 6. 获取解析器列表
function axiosGetParserList(appId, fnSuccess) {
  const res = [
    { parserId: '001', parserName: '姓名解析器', parserUrl: '' },
    { parserId: '002', parserName: '地址解析器', parserUrl: '' },
    { parserId: '003', parserName: '时间解析器', parserUrl: '' },
    { parserId: '004', parserName: '身份证号解析器', parserUrl: '' },
    { parserId: '005', parserName: '是否解析器', parserUrl: '' },
  ];
  fnSuccess(res);
}

export default {
  axiosGetScenarioList,
  aioxsCreateScenario,
  axiosDeleteTask,
  axiosUpdateTaskDetail,
  axiosGetScenarioDetail,
  axiosGetIntentsList,
  axiosGetParserList,
};
