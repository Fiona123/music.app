/*
api.js is used to wrapped to a request library
now the wrapped function includes: get, post, custom
*/
import axios from 'axios'

function checkCode(context, response) {
    let res = response.data
    // to be compatible with ie11
    if (!Number.isInteger) {
        // eslint-disable-next-line
        Number.isInteger = function (num) {
            return typeof num === 'number' && num % 1 === 0
        }
    }
    if (res == null
        || !Number.isInteger(res.error_code)
        || !res.error_message
        || res.data === undefined) {
        res = {
            error_code: -99,
            error_message: '通讯故障，得到未知的数据格式'
        }
    }
    if (res.error_code >= 0) {
        return res
    }
    // 如果登录信息过期，直接返回到登录页面，不需要弹出对话框提示错误信息
    // if (res.error_code === -10) {
    //     this.$clearAllCookie()
    //     const etype = this.$getCookie('enterprise_type')
    //     if (etype === 2) {
    //         window.top.location.href = 'basic.html'
    //     } else {
    //         window.top.location.href = 'enterprise.html'
    //     }
    //     return false
    // }
    this.$alert(res.error_message, '提示', {
        confirmButtonText: '确定',
        type: 'error'
    }).then(() => {
        if (res.error_code === -8) {
            window.location.href = '#robotpage'
            return false
        }
        return res
    })
    return res
}

function axiosReq(url, type, params, timeout, token, responseType) {
    const that = this
    const options = {}
    options.url = url
    options.method = type
    if (responseType) {
        options.responseType = responseType
    }
    options.timeout = timeout
    if (params) {
        if (type === 'get') {
            options.params = params
        } else {
            options.data = params
        }
    }
    let axiosInstance = axios.create()
    if (responseType === 'blob') {
        axiosInstance = axios.create({ responseType: 'blob' })
    }
    axiosInstance.defaults.baseURL = '/api'
    axiosInstance.defaults.retry = 2
    axiosInstance.defaults.retryDelay = 1000

    if (token) {
        axiosInstance.interceptors.request.use((config) => {
            config.headers.Access_token = this.$getCookie('access_token')
            return config
        }, error => Promise.reject(error))
    }

    axiosInstance.interceptors.response.use(undefined, (err) => {
        const configs = err.config
        if (!configs || !configs.retry) return Promise.reject(err)
        // Set the variable for keeping track of the retry count
        configs.retryCount = configs.retryCount || 0
        // Check if we've maxed out the total number of retries
        if (configs.retryCount >= configs.retry) {
            // Reject with the error
            return Promise.reject(err)
        }
        // Increase the retry count
        configs.retryCount += 1
        // Create new promise to handle exponential backoff
        const backoff = new Promise((resolve) => {
            setTimeout(() => {
                resolve()
            }, configs.retryDelay || 1)
        })
        configs.baseURL = ''
        // Return the promise in which recalls axios to retry the request
        return backoff.then(() => axiosInstance(configs))
    })

    return axiosInstance(options).then((response) => {
        let res = response
        if (options.responseType !== 'blob') {
            res = checkCode.bind(this)(that, response)
        }
        return res
    }).catch(err => Promise.reject(err))
}

// to deal with get request
function axiosGet(url, params, token = true, timeout = 20000, responseType) {
    return this.$axiosReq(url, 'get', params, timeout, token, responseType)
}

// to deal with post request
function axiosPost(url, params, token = true, timeout = 20000) {
    return this.$axiosReq(url, 'post', params, timeout, token)
}

// to deal with the custom request
function axiosCustom(url, type = 'post', params, token = true, timeout = 20000) {
    return this.$axiosReq(url, type, params, timeout, token)
}

// to deal with get request
function axiosExport(url, params, token = true, timeout = 20000, responseType) {
    return this.$axiosGet(url, params, token, timeout, responseType)
}

function axiosExportNoRetry(url, params, token = true, timeout = 400 * 1000, responseType) {
    return this.$axiosGet(url, params, token, timeout, responseType)
}

const axiosPlugin = {
    install(Vue) {
        Vue.prototype.$axiosReq = axiosReq
        Vue.prototype.$axiosGet = axiosGet
        Vue.prototype.$axiosPost = axiosPost
        Vue.prototype.$axiosCustom = axiosCustom
        Vue.prototype.$axiosExport = axiosExport
        Vue.prototype.$axiosExportNoRetry = axiosExportNoRetry
    }
}

export default axiosPlugin
