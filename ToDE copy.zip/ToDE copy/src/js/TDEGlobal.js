
// 获得BOT问模板
const GetBotQTemplate = () => {
  // 新增BOT问的默认值 - 需要设置nodeId & title
  const BotQTemplateObj = {
      // 需要设置初始值，每个node不一样
      nodeId: '',
      title: '',
      isGlobal: false, // 是否为全局通用问题
      isRelevant: false, // 是否为关联问
      relevantParent: {
        // nodeId: '84212722430001',
        // answerType: '文本',
      },
      // 初始值为空
      parserId: '',
      presetTexts: [{
        'title': '预设问题',
        'value': '',
      }],
      answerTypes: [
        { type: '告知', enabled: true, navigations: [], },
        { type: '文本', enabled: false, navigations: [], },
        { type: '提问', enabled: false, navigations: [], },
        { type: '不知道', enabled: false, navigations: [], },
        { type: '催促', enabled: false, navigations: [], },
        { type: '未能获得答案', enabled: false, navigations: [],},
        { type: '全选', enabled: false, navigations: [], },
        { type: '不确定', enabled: false, navigations: [], },
        { type: '随意', enabled: false, navigations: [], },
        { type: '拒绝告知', enabled: false, navigations: [], },
        { type: '回避', enabled: false, navigations: [], },
        { type: '是', enabled: false, navigations: [], },
        { type: '否', enabled: false, navigations: [], },
        { type: '其他', enabled: true, navigations: [], },
      ],
      generalAnswerType: [
        {type: '告知', enabled: true },
        {type: '转人工', enabled: true },
        {type: '继续', enabled: true },
        {type: '命令重复', enabled: true },
        {type: '寒暄', enabled: true },
        {type: '告知等待', enabled: true },
        {type: '告别', enabled: true },
        {type: '退出', enabled: true },
      ],
  };
  return BotQTemplateObj;
};

// BOT问中系统预设话术类别，共4类：
const SystemPresetTexts = ['预设问题', '重复问题', '解析失败', '场景延续话术'];


// 回答类型中 - 条件 - 变量关系操作符
const conditionOperators = [
  {label: '等于', value: '=', type: 'Binary' },
  {label: '存在', value: 'exist', type: 'Unary'},
  {label: '大于', value: '>', type: 'Binary' },
  {label: '大于等于', value: '>=', type: 'Binary' },
  {label: '小于', value: '<', type: 'Binary' }, 
  {label: '小于等于', value: '<=', type: 'Binary' }, 
];

// 回答类型 - 动作 - 新增动作类型
const ActionTypes = [
  { label: '文字回复', value: 'TextReply' },
  { label: '赋值', value: 'Assignment' },
  { label: '自定义服务', value: 'WebApi' },
];

export default {
  SystemPresetTexts,
  GetBotQTemplate,
  conditionOperators,
  ActionTypes,
};
