<template>
  <div id="app">
    <task-engine></task-engine>
  </div>
</template>

<script>
import TaskEngine from './components/TaskEngine';

export default {
  name: 'App',
  components: {
    TaskEngine,
  },
};
</script>

<style>
#app {
  width:100%;
  height: 100%;
  background: #EEEEEE;
}
</style>
