<template>
  <div class="edit-answ-detail-wrapper">  
    <div class="menu-bar">
      <span class="add-con-btn" @click="handleAddCondition">+新增条件</span>
      <el-dropdown class="tde-el-dropdown add-action-btn" @command="handleAddAction">
        <span class="el-dropdown-link">+新增动作</span>
        <el-dropdown-menu slot="dropdown">
          <el-dropdown-item v-for="(item, key) in ActionTypes" :key="key" :command="item.value">{{item.label}}</el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>
      <span class="del-nav-btn" @click="handleDeleteNavigation">删除</span>
    </div>
    <div v-if="NAV.conditions && NAV.conditions instanceof Array" class="conditions-wrapper">
      <div class="condition-header" v-show="NAV.conditions.length > 0">
        <span>符合</span>
        <el-select v-model="NAV.operator" placeholder="请选择" class="tde-el-select cond-relation-select">
          <el-option v-for="relation in conditionRelations" :key="relation.value" :label="relation.label" :value="relation.value"></el-option>
        </el-select>
        <span>以下条件</span>
      </div>
      <div class="condition-box" v-for="condition in NAV.conditions">
        <div class="delete-box">
          <span>如果 场景已收集数据</span>
          <img src="../assets/images/delete_s.png" @click="handleDeleteCondition(condition)">
        </div>
        <div class="cond-line-1">
          <el-input class="tde-el-input param-1" v-model="condition.param1"></el-input>
          <el-select v-model="condition.operator" placeholder="请选择" class="tde-el-select cond-operator-select">
            <el-option v-for="operator in conditionOperators" :key="operator.value" :label="operator.label" :value="operator.value"></el-option>
          </el-select>
        </div>
        <div class="cond-line-2" v-if="shouldShowCondLine2(condition.operator)">
          <el-select v-model="condition.param2type" placeholder="请选择" class="tde-el-select p2-type">
            <el-option v-for="type in typesOfParam2" :key="type.value" :label="type.label" :value="type.value"></el-option>
          </el-select>
          <el-input class="tde-el-input p2-value" v-model="condition.param1value"></el-input>
        </div>
      </div>
    </div>
    <div class="action-wrapper">
      <div class="action-header">执行动作</div>
      <div v-for="(action, index) in OtherActions" :key="index">
        <div class="text-reply-box action-box" v-if="action.type === 'TextReply'">
          <div class="line-1">
            <span>文字回复</span>
            <el-input class="tde-el-input" v-model="action.text"></el-input>
            <img src="../assets/images/delete_s.png" @click="handleDeleteAction(action)">
          </div>
          <div class="line-2">
            <span>数据关联</span>
            <el-radio v-model="action.dataRelated" :label="true">开</el-radio>
            <el-radio v-model="action.dataRelated" :label="false">关</el-radio>
          </div>
        </div>
        <div class="assignment-box action-box" v-else-if="action.type === 'Assignment'">
          <div class="assign-line-1">
            <span>赋值</span>
            <el-input v-model="action.target" class="tde-el-input input-variant" placeholder="输入变量名"></el-input>
            <img src="../assets/images/delete_s.png" @click="handleDeleteAction(action)">
          </div>
          <div class="assign-line-2">
            <span>等于</span>
            <el-input v-model="action.value" class="tde-el-input input-value" placeholder="输入值"></el-input>
          </div>
        </div>
        <div class="web-api-box action-box" v-else-if="action.type === 'WebApi'">
          <div class="web-api-line-1">
            <span>自定义服务</span>
            <img src="../assets/images/delete_s.png" @click="handleDeleteAction(action)">
          </div>
          <el-input class="tde-el-input" v-model="action.url"></el-input>
        </div>
      </div>  
      <div class="navigate-to-box action-box">
        <div class="to-node-id">
          <span>前往</span>
          <el-select @change="handleSelectNav2Node" filterable clearable v-model="NAV.action.navigateTo.nodeId" placeholder="请选择" class="tde-el-select select-to-node">
            <el-option :class="{'create-node-option': node.nodeId==='create-node'}" v-for="node in navigateToNodeList" :key="node.nodeId" :label="node.title" :value="node.nodeId"></el-option>
          </el-select>
        </div>
        <div class="to-node-text" v-show="NAV.action.navigateTo.nodeId && NAV.action.navigateTo.nodeId!=='exit'">
          <span>预设问题</span>
          <el-select @change="handleSelectNav2Text" v-model="NAV.action.navigateTo.nodePresetTexts" placeholder="请选择" class="tde-el-select select-to-node">
            <el-option v-for="text in currentPresetTexts" :key="text.title" :label="text.title" :value="text.title"></el-option>
          </el-select>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import TDEGlobal from '../js/TDEGlobal';

export default {
  props: {
    NAV: {
      type: Object,
      default() {
        return {};
      }
    },
    currentNodeList: {
      type: Array,
      default() {
        return [];
      }
    },
    currentNodeMap: {
      type: Object,
    }
  },
  computed: {
    navigateToNodeList() {
      const createNode = {
        nodeId: 'create-node',
        title: '+创建新问题',
      };
      return [createNode].concat(this.currentNodeList);
    },
    currentPresetTexts() {
      const nodeId = this.NAV.action.navigateTo.nodeId;
      const nodeData = this.currentNodeMap[nodeId];
      if (!nodeData) {
        return [];
      }
      return nodeData.presetTexts;
    },
    conditionOperators() {
      return TDEGlobal.conditionOperators || [];
    },
    ActionTypes() {
      return TDEGlobal.ActionTypes || [];
    },
    OtherActions() {
      return this.NAV.action.otherActions || []; 
    },
  },
  data() {
    return {
      // 满足【任意】或【全部】条件
      conditionRelations: [
        {label: '任意', value: 'or'},
        {label: '全部', value: 'and'}
      ],
      // 条件判断中，第二个操作数为变量或者为值
      typesOfParam2: [
        {label: '值', value: 'value'},
        {label: '变量', value: 'variant'}
      ],
      oldNavId: '',
    };
  },
  created() {
    this.oldNavId = this.NAV.action.navigateTo.nodeId;
  },
  watch: {
    NAV() {
      this.oldNavId = this.NAV.action.navigateTo.nodeId;
    }
  },
  methods: {
    handleSelectNav2Node(selNodeId) {
      // console.log(`selNodeId = ${selNodeId} --- oldNavId = ${this.oldNavId}`);
      console.log(`this.oldNaviId = ${this.oldNavId}   --- newVal = ${selNodeId}`);
      if (selNodeId === 'create-node') {
        this.NAV.action.navigateTo.nodeId = this.oldNavId;
        this.$emit('createRelevantNode', this.NAV);
        return;
      }
      if (selNodeId === 'exit' || selNodeId === '' ) {
        // 选择退出结点
        this.handleChangeNavToNode(this.oldNavId, selNodeId, '');
      } else {
        this.NAV.action.navigateTo.nodePresetTexts = '';
      }
    },
    handleSelectNav2Text(selText) {
      this.handleChangeNavToNode(this.oldNavId, this.NAV.action.navigateTo.nodeId, selText);
    },
    handleChangeNavToNode(oldNodeId, newNodeId, preText) {
      this.oldNavId = newNodeId;
      if (!oldNodeId) {
        this.$emit('add2Node', this.NAV, newNodeId, preText);
      } else if(!newNodeId) {
        this.$emit('delete2Node', this.NAV, oldNodeId, preText);
      } else {
        this.$emit('update2Node', this.NAV, oldNodeId, newNodeId, preText);
      }
    },
    // 条件中是否显示第二行 - 是否为二元运算符
    shouldShowCondLine2(operator) {
      let res = true;
      this.conditionOperators.forEach((item) => {
        if (item.value === operator && item.type === 'Unary' ) {
          res = false;
        }
      });
      return res;
    },
    // 删除当前导向
    handleDeleteNavigation() {
      this.$emit('delete', this.NAV);
    },
    // 新增条件
    handleAddCondition() {
      if (!this.NAV.conditions instanceof Array) {
        this.NAV.conditions = [];
      }
      const condition = {
        param1: '',
        operator: '>=',
        parem2type: 'value',
        parem2value: '',
      }
      this.NAV.conditions.push(condition);
    },
    // 删除条件
    handleDeleteCondition(condition) {
      const index = this.NAV.conditions.indexOf(condition);
      this.NAV.conditions.splice(index, 1);
    },
    // 新增动作
    handleAddAction(type) {
      let action = {};
      if (type === 'TextReply') {
        action = { type, text: '', dataRelated: false };
      } else if (type === 'Assignment') {
        action = { type, target: '', value: '' };
      } else if (type === 'WebApi') {
        action = { type, url: ''}
      } else {
        return;
      }
      if (!this.NAV.action.otherActions || !this.NAV.action.otherActions instanceof Array ) {
        this.NAV.action.otherActions = [];
      }
      this.NAV.action.otherActions = this.NAV.action.otherActions.concat([action]);
    },
    // 删除动作
    handleDeleteAction(action) {
      const index = this.NAV.action.otherActions.indexOf(action);
      this.NAV.action.otherActions.splice(index, 1);
    }
  },
};
</script>

<style lang="scss" scoped>
@import "../assets/scss/style";
.edit-answ-detail-wrapper{
  font-size: 12px;
  border:1px solid rgba(233,233,233,1);
  background-color: #FFFFFF;
  .menu-bar{
    display: flex;
    padding: 10px;
    background-color: rgba(247,247,247,1);
    span{
      line-height: 20px;
      height: 20px;
      cursor: pointer;
    }
    .add-con-btn,{
      color: #333333;
      &:hover{
        color: #1875F0;
      }
    }
    /deep/ .add-action-btn{
      margin-left: 20px;
      width: 100px;
      span{
        color: #333333;
        &:hover{
          color: #1875F0;
        }
      }
    }
    .del-nav-btn{
      flex: 1;
      text-align: right;
      color: #F25C62;
    }
  }
  .conditions-wrapper{
    .condition-header{
      padding: 10px 10px 5px 10px;
      .cond-relation-select{
        width: 80px;
        height: 28px;
        margin: 0px 10px;
      }
      >span{
        color: #666666;
      }
    }
    .condition-box{
      padding: 10px;
      margin-top: 5px;
      background-color: rgba(247,247,247,1);
      .delete-box{
        display: flex;
        align-items: center;
        margin-bottom: 4px;
        span{
          flex: 1;
          line-height: 20px;
          height: 20px;
        }
        img{
          width: 10px;
          height: 12px;
          cursor: pointer;
        }
      }
      .cond-line-1{
        display: flex;
        .param-1{
          flex: 2;
        }
        .cond-operator-select{
          flex: 1;
          margin-left: 10px;
          height: 28px;
        }
      }
      .cond-line-2{
        margin-top: 10px;
        display: flex;
        .p2-type{
          height: 28px;
          flex: 1;
        }
        .p2-value{
          height: 28px;
          flex: 2;
          margin-left: 10px;
        }
      }
    }
  }
  .action-wrapper{
    box-shadow:0px 1px 0px 0px rgba(233,233,233,1);
    .action-header{
      color: #333333;
      font-weight: bold;
      height: 20px;
      line-height: 20px;
      padding: 10px 10px 0px 10px;
    }
    .action-box{
      margin-top: 10px;
      background:rgba(247,247,247,1);
      &.text-reply-box{
        .line-1{
          display: flex;
          align-items: center;
          padding: 10px;
          span{
            margin-right: 10px;
            display: inline-block;
          }
          .el-input{
            flex: 1;
            margin-right: 10px;
          }
          img{
            width: 10px;
            height: 12px;
            cursor: pointer;
          }
        }
        .line-2{
          display: flex;
          align-items: center;
          padding: 0px 10px 10px 10px;
          .el-radio{
            /deep/ >span{
              font-size: 12px;
            }
            margin-left: 10px;
          }
        }
      }
      &.assignment-box{
        padding: 10px; 
        .assign-line-1, .assign-line-2{
          display: flex;
          align-items: center;
          span{
            width: 48px;
          }
          .el-input{
            flex: 1;
            margin-left: 10px;
          }
          img{
            margin-left: 10px;
            width: 10px;
            height: 12px;
            cursor: pointer;
          }
        }
        .assign-line-2{
          margin-top: 10px;
        }
      }
      &.web-api-box{
        padding: 10px;
        .web-api-line-1{
          margin-bottom: 10px;
          display: flex;
          align-items: center;
          span{
            flex: 1;
          }
          img{
            margin-left: 10px;
            width: 10px;
            height: 12px;
            cursor: pointer;
          }
        } 
        .el-input{
          flex: 1;
          width: 100%;
        }
      }
      &.navigate-to-box{
        padding: 10px;
        .to-node-id, .to-node-text{
          display: flex;
          align-items: center;
          span{
            width: 48px;
          }
          .el-select{
            flex: 1;
            height: 28px;
            margin-left: 10px;
          }
        }
        .to-node-text{
          margin-top: 10px;
        }
      }
    }
  }
}
</style>
