<template>
  <div class="edit-trigger-wrapper">
  <div class="condition-wrapper">
    <el-tooltip effect="dark" placement="left" :manual="true" :value="isTooltipOpen">
      <div class="tooltip-text" slot="content">
        <p style="font-weight: bold;">1. 首先</p>
        <p style="margin-top: 5px;">进行条件设置，怎样触发这个场景</p>
      </div>
      <p class="title">触发条件设置</p>
    </el-tooltip>
    <div class="condition-box">
      <div class="menu-bar">
        <el-dropdown class="tde-el-dropdown" @command="handleAddTrigger">
          <span class="el-dropdown-link">
            新增条件<i class="el-icon-arrow-down el-icon--right"></i>
          </span>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item command="intent">意图</el-dropdown-item>
            <el-dropdown-item command="keyword">关键字</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
      </div>
      <div v-for="(item, index) in triggers" class="triggers-box">
        <span class="gap-span" v-html="index===0?'如':'或'"></span>
        <el-select v-if="item.type==='intent'" v-model="item.intentId"
        placeholder="选择意图" class="tde-el-select" @change="handleSaveChange">
          <el-option v-for="item in intentsList" :key="item.intentId" :label="item.intentTitle" :value="item.intentId">
        </el-option>
        </el-select>
        <el-input v-else v-model="item.value" placeholder="输入关键字" class="tde-el-input" @change="handleSaveChange"></el-input>
        <img src="../assets/images/delete_s.png" @click="handleDeleteTrigger(item)">
      </div>
      <p>则前往 第一个问题</p>
    </div>
  </div>
 <!--  <div class="navigators">
    <span>解析器管理</span>
    <span>词库管理</span>
  </div> -->
  </div>
</template>

<script>
import api from '../js/taskengineapi';

export default {
  props: {
    triggers: {
      type: Array,
      default() {
        return [];
      },
    },
  },
  data() {
    return {
      isTooltipOpen: false,
      intentsList: []
    };
  },
  created() {
    api.axiosGetIntentsList.call(this, 'appId', (list) => {
      this.intentsList = list;
      console.log(`this.intentsList = ${this.intentsList}`);
    });
  },
  mounted() {
    if (this.triggers.length === 0) {
      window.setTimeout(() => {
        this.isTooltipOpen = true;
      }, 200);
    }
  },
  methods: {
    handleAddTrigger(type) {
      this.triggers.push({ type, value: '' });
      this.isTooltipOpen = false;
    },
    handleDeleteTrigger(item) {
      const index = this.triggers.indexOf(item);
      this.triggers.splice(index, 1);
    },
    handleSaveChange() {
      this.$emit('change', this.triggers);
    },
  },
};
</script>

<style lang="scss" scoped>
@import "../assets/scss/style";
.edit-trigger-wrapper{
  background: #FFFFFF;
  width: 100%;
  .condition-wrapper{
    width: 100%;
    box-shadow:0px 1px 0px 0px rgba(233,233,233,1);
    padding-bottom: 20px;
    .title{
      color: #999999;
      height: 40px;
      line-height: 40px;
      font-size:12px;
      margin-left: 10px;
      padding-left: 10px;
    }
    .condition-box{
      box-sizing: border-box;
      width: calc(100% - 20px);
      margin: 0px 10px;
      border-radius:2px;
      border: 1px solid rgba(233,233,233,1);
      .menu-bar{
        height:38px;
        line-height: 38px;
        padding-left: 10px;
        background:rgba(247,247,247,1);
        box-shadow:0px 1px 0px 0px rgba(233,233,233,1);
        color: #333333;
        .tde-el-dropdown{
          width: 100px;
        }
      }
      .triggers-box{
        width: 100%;
        padding: 10px 10px 0px 10px;
        box-sizing: border-box;
        .gap-span{
          display: inline-block;
          margin-right: 6px;
        }
        .el-select{
          height: 28px;
          width: calc(100% - 50px);
          /deep/ .el-input{
            height: 28px;
            input{
              height: 28px;
              font-size: 12px;
            }
          }
        }
        .el-input{
          width: calc(100% - 50px);
          /deep/ input{
            height: 28px;
          }
        }
        img{
          margin-left: 8px;
          padding-top: 2px;
          width: 10px;
          cursor: pointer;
        }
      }
      p{
        margin: 10px;
        font-size:12px;
        color: #666666;
        line-height:20px;
      }
    }
  }
  .navigators{
    padding: 20px 10px;
    display: flex;
    span{
      flex: 1;
      height:46px;
      line-height: 46px;
      border-radius:2px;
      border:1px solid rgba(219,219,219,1);
      text-align: center;
      font-size: 14px;
      cursor: pointer;
      &:first-child{
        margin-right: 10px;
      }
    }
  }
}
.el-select-dropdown {
  /deep/ .el-select-dropdown__empty{
    height: 28px;
    padding: 0px;
  }
}
</style>
