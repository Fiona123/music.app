import go from 'gojs';

const $ = go.GraphObject.make;
const backColor = '#EAF3FF';
const lineColor = '#3D80FF';

go.GraphObject.defineBuilder('CircleButton', () => {
  // default colors for 'Button' shape
  const buttonFillNormal = backColor;
  const buttonStrokeNormal = lineColor;
  const buttonFillOver = backColor;
  const buttonStrokeOver = lineColor;
  const buttonFillPressed = backColor;
  const buttonStrokePressed = lineColor;
  const buttonFillDisabled = backColor;
  // padding inside the ButtonBorder to match sizing from previous versions
  const paddingHorizontal = 2.76142374915397;
  const paddingVertical = 2.761423749153969;
  const button = ($(go.Panel, 'Auto', {
    isActionable: true,
    enabledChanged: (btn, enabled) => {
      const shape = btn.findObject('ButtonBorder');
      if (shape !== null) {
        // eslint-disable-next-line
        shape.fill = enabled ? btn['_buttonFillNormal'] : btn['_buttonFillDisabled'];
      }
    },
    cursor: 'pointer',
    // save these values for the mouseEnter and mouseLeave event handlers
    _buttonFillNormal: buttonFillNormal,
    _buttonStrokeNormal: buttonStrokeNormal,
    _buttonFillOver: buttonFillOver,
    _buttonStrokeOver: buttonStrokeOver,
    _buttonFillPressed: buttonFillPressed,
    _buttonStrokePressed: buttonStrokePressed,
    _buttonFillDisabled: buttonFillDisabled,
  }, $(go.Shape, {
    name: 'ButtonBorder',
    figure: 'Circle',
    spot1: new go.Spot(0, 0, paddingHorizontal, paddingVertical),
    spot2: new go.Spot(1, 1, -paddingHorizontal, -paddingVertical),
    parameter1: 2,
    parameter2: 2,
    fill: buttonFillNormal,
    stroke: buttonStrokeNormal,
  })));
  // There's no GraphObject inside the button shape
  // it must be added as part of the button definition.
  // This way the object could be a TextBlock or a Shape or a Picture or arbitrarily complex Panel.
  // mouse-over behavior
  const overButton = (e, btn) => {
    const over = e.diagram.findObjectAt(e.documentPoint, (x) => {
      while (x.panel !== null) {
        if (x.isActionable) {
          return x;
        }
        // eslint-disable-next-line
        x = x.panel;
      }
      return x;
    }, x => x === btn);
    return over !== null;
  };
  button.mouseEnter = (e, btn) => {
    if (!btn.isEnabledObject()) {
      return;
    }
    if (!(btn instanceof go.Panel)) {
      return;
    }
    const shape = btn.findObject('ButtonBorder'); // the border Shape
    if (shape instanceof go.Shape) {
      // eslint-disable-next-line
      let brush = btn['_buttonFillOver'];
      // eslint-disable-next-line
      btn['_buttonFillNormal'] = shape.fill;
      shape.fill = brush;
      // eslint-disable-next-line
      brush = btn['_buttonStrokeOver'];
      // eslint-disable-next-line
      btn['_buttonStrokeNormal'] = shape.stroke;
      shape.stroke = brush;
    }
  };
  button.mouseLeave = (e, btn) => {
    if (!btn.isEnabledObject()) {
      return;
    }
    if (!(btn instanceof go.Panel)) {
      return;
    }
    const shape = btn.findObject('ButtonBorder'); // the border Shape
    if (shape instanceof go.Shape) {
      // eslint-disable-next-line
      shape.fill = btn['_buttonFillNormal'];
      // eslint-disable-next-line
      shape.stroke = btn['_buttonStrokeNormal'];
    }
  };
  button.actionDown = (e, btn) => {
    if (!btn.isEnabledObject()) {
      return;
    }
    if (!(btn instanceof go.Panel)) {
      return;
    }
    // eslint-disable-next-line
    if (btn['_buttonFillPressed'] === null) {
      return;
    }
    if (e.button !== 0) {
      return;
    }
    const shape = btn.findObject('ButtonBorder'); // the border Shape
    if (shape instanceof go.Shape) {
      const { diagram } = e;
      const oldskip = diagram.skipsUndoManager;
      diagram.skipsUndoManager = true;
      // eslint-disable-next-line
      let brush = btn['_buttonFillPressed'];
      // eslint-disable-next-line
      btn['_buttonFillOver'] = shape.fill;
      shape.fill = brush;
      // eslint-disable-next-line
      brush = btn['_buttonStrokePressed'];
      // eslint-disable-next-line
      btn['_buttonStrokeOver'] = shape.stroke;
      shape.stroke = brush;
      diagram.skipsUndoManager = oldskip;
    }
  };
  button.actionUp = (e, btn) => {
    if (!btn.isEnabledObject()) {
      return;
    }
    if (!(btn instanceof go.Panel)) {
      return;
    }
    // eslint-disable-next-line
    if (btn['_buttonFillPressed'] === null) {
      return;
    }
    if (e.button !== 0) {
      return;
    }
    const shape = btn.findObject('ButtonBorder'); // the border Shape
    if (shape instanceof go.Shape) {
      const { diagram } = e;
      const oldskip = diagram.skipsUndoManager;
      diagram.skipsUndoManager = true;
      if (overButton(e, btn)) {
        // eslint-disable-next-line
        shape.fill = btn['_buttonFillOver'];
        // eslint-disable-next-line
        shape.stroke = btn['_buttonStrokeOver'];
      } else {
        // eslint-disable-next-line
        shape.fill = btn['_buttonFillNormal'];
        // eslint-disable-next-line
        shape.stroke = btn['_buttonStrokeNormal'];
      }
      diagram.skipsUndoManager = oldskip;
    }
  };
  button.actionCancel = (e, btn) => {
    if (!btn.isEnabledObject()) {
      return;
    }
    if (!(btn instanceof go.Panel)) {
      return;
    }
    // eslint-disable-next-line
    if (btn['_buttonFillPressed'] === null) {
      return;
    }
    const shape = btn.findObject('ButtonBorder'); // the border Shape
    if (shape instanceof go.Shape) {
      const { diagram } = e;
      const oldskip = diagram.skipsUndoManager;
      diagram.skipsUndoManager = true;
      if (overButton(e, btn)) {
        // eslint-disable-next-line
        shape.fill = btn['_buttonFillOver'];
        // eslint-disable-next-line
        shape.stroke = btn['_buttonStrokeOver'];
      } else {
        // eslint-disable-next-line
        shape.fill = btn['_buttonFillNormal'];
        // eslint-disable-next-line
        shape.stroke = btn['_buttonStrokeNormal'];
      }
      diagram.skipsUndoManager = oldskip;
    }
  };
  button.actionMove = (e, btn) => {
    if (!btn.isEnabledObject()) {
      return;
    }
    if (!(btn instanceof go.Panel)) {
      return;
    }
    // eslint-disable-next-line
    if (btn['_buttonFillPressed'] === null) {
      return;
    }
    const { diagram } = e;
    if (diagram.firstInput.button !== 0) {
      return;
    }
    diagram.currentTool.standardMouseOver();
    if (overButton(e, btn)) {
      const shape = btn.findObject('ButtonBorder');
      if (shape instanceof go.Shape) {
        const oldskip = diagram.skipsUndoManager;
        diagram.skipsUndoManager = true;
        // eslint-disable-next-line
        let brush = btn['_buttonFillPressed'];
        if (shape.fill !== brush) {
          shape.fill = brush;
        }
        // eslint-disable-next-line
        brush = btn['_buttonStrokePressed'];
        if (shape.stroke !== brush) {
          shape.stroke = brush;
        }
        diagram.skipsUndoManager = oldskip;
      }
    }
  };
  return button;
});

go.GraphObject.defineBuilder('TreeExpanderCircleButton', () => {
  const button = ($('CircleButton', {
    _treeExpandedFigure: 'MinusLine',
    _treeCollapsedFigure: 'PlusLine',
  }, go.GraphObject.make(go.Shape, {
    name: 'ButtonIcon',
    figure: 'MinusLine',
    stroke: lineColor,
    strokeWidth: 1,
    desiredSize: new go.Size(8, 8),
  },
  // bind the Shape.figure to the Node.isTreeExpanded value using this converter:
  new go.Binding('figure', 'isTreeExpanded', (exp, shape) => {
    const but = shape.panel;
    // eslint-disable-next-line
    return exp ? but['_treeExpandedFigure'] : but['_treeCollapsedFigure'];
  }).ofObject()),
  // assume initially not visible because there are no links coming out
  { visible: false },
  // bind the button visibility to whether it's not a leaf node
  new go.Binding('visible', 'isTreeLeaf', leaf => !leaf).ofObject()));
  // tree expand/collapse behavior
  button.click = (e, btn) => {
    let node = btn.part;
    if (node instanceof go.Adornment) {
      node = node.adornedPart;
    }
    if (!(node instanceof go.Node)) {
      return;
    }
    const { diagram } = node;
    if (diagram === null) {
      return;
    }
    const cmd = diagram.commandHandler;
    if (node.isTreeExpanded && !cmd.canCollapseTree(node)) {
      return;
    }
    if (!node.isTreeExpanded && !cmd.canExpandTree(node)) {
      return;
    }
    e.handled = true;
    if (node.isTreeExpanded) {
      cmd.collapseTree(node);
    } else {
      cmd.expandTree(node);
    }
  };
  return button;
});


// 设置背景色和边框色
const selectColor = '#3D80FF';
const setNodeColor = (node, id, strokeColor, fillColor) => {
  const shape = node.findObject(id);
  if (shape instanceof go.Shape || shape instanceof go.TextBlock) {
    if (shape.fill === selectColor) {
      // 当前选中的颜色
      return;
    }
    if (shape.fill) {
      shape.fill = fillColor;
    }
    if (shape.stroke) {
      shape.stroke = strokeColor;
    }
  }
};

go.GraphObject.defineBuilder('FunctionNode', () => {
  const strokeWidth = 1;

  const normalStrokeColor = '#DBDBDB';
  const normalFillColor = '#FFFFFF';

  const hoverStrokeColor = '#B1CCFF';
  const hoverFillColor = '#FFFFFF';

  const normalFontColor = '#666666';
  const hoverFontColor = '#1875F0';
  // 圆弧形状
  const w = 100;
  const h = 34;
  const geo2 = new go.Geometry();
  const fig2 = new go.PathFigure(0.3 * h, 0, true);
  geo2.add(fig2);
  fig2.add(new go.PathSegment(go.PathSegment.Arc, 270, 180, w - h * 0.3, h * 0.5, 10, h * 0.5));
  fig2.add(new go.PathSegment(go.PathSegment.Arc, 90, 180, h * 0.3, h * 0.5, 10, h * 0.5));


  const panel = $(go.Panel, 'auto', {},
    new go.Binding('margin', 'key', (key) => {
      if (key === 'RobotQRoot' || key === 'GeneralQRoot') {
        return new go.Margin(0, 0, 0, 10);
      }
      return new go.Margin(0, 0, 0, 40);
    }),
    new go.Binding('width', 'key', (key) => {
      if (key === 'RobotQRoot' || key === 'GeneralQRoot') {
        return 0;
      }
      return 180;
    }),
    $(go.Panel, 'auto', {},
      new go.Binding('visible', 'key', key => key !== 'GapNode' && key !== 'TitleNode'),
      $(go.Shape, {
        name: 'FUNC_SHAPE', width: 170, height: 34, fill: normalFillColor, strokeDashArray: [2, 2, 2, 2], stroke: normalStrokeColor, strokeWidth, geometry: geo2,
      }),
      $(go.TextBlock, 'FUNCTION', {
        name: 'FUNC_TEXT', font: 'normal 13px PingFangSC-Regular', stroke: normalFontColor, margin: new go.Margin(11, 0, 0, 14),
        editable: true, isMultiline: false, minSize: new go.Size(112, 10), maxSize: new go.Size(112, 16),
      },
      new go.Binding('text', 'nodeName').makeTwoWay(),
      new go.Binding('textEdited', 'funcChangeTitle'))),
    $(go.Panel, { width: 170, height: 34, background: 'transparent' },
      new go.Binding('visible', 'key', key => key === 'GapNode')),
    $(go.TextBlock, {
      stroke: '#666666', font: 'normal 14px PingFangSC-Regular', margin: new go.Margin(0, 0, 0, 10),
    },
    new go.Binding('text', 'nodeName'),
    new go.Binding('visible', 'key', key => key === 'TitleNode')));

  panel.mouseEnter = (e, obj) => {
    setNodeColor(obj, 'FUNC_SHAPE', hoverStrokeColor, hoverFillColor);
    setNodeColor(obj, 'FUNC_TEXT', hoverFontColor, hoverFontColor);
  };
  panel.mouseLeave = (e, obj) => {
    setNodeColor(obj, 'FUNC_SHAPE', normalStrokeColor, normalFillColor);
    setNodeColor(obj, 'FUNC_TEXT', normalFontColor, normalFontColor);
  };
  return panel;
});

go.GraphObject.defineBuilder('QuestionNode', () => {
  const strokeWidth = 1;

  const normalStrokeColor = '#E7ECF0';
  const normalFillColor = '#E7ECF0';

  const hoverStrokeColor = '#B0CCFF';
  const hoverFillColor = '#E7ECF0';

  const fontColor = '#6B8093';
  const fontColorLeaf = '#666666';
  // 圆弧形状
  const w = 100;
  const h = 34;
  const geo = new go.Geometry();
  const fig = new go.PathFigure(0.5 * h, 0, true);
  geo.add(fig);
  fig.add(new go.PathSegment(go.PathSegment.Arc, 270, 180, w - h * 0.5, h * 0.5, 17, h * 0.5));
  fig.add(new go.PathSegment(go.PathSegment.Arc, 90, 180, h * 0.5, h * 0.5, 17, h * 0.5));
  const geo2 = new go.Geometry();
  const fig2 = new go.PathFigure(0.3 * h, 0, true);
  geo2.add(fig2);
  fig2.add(new go.PathSegment(go.PathSegment.Arc, 270, 180, w - h * 0.3, h * 0.5, 10, h * 0.5));
  fig2.add(new go.PathSegment(go.PathSegment.Arc, 90, 180, h * 0.3, h * 0.5, 10, h * 0.5));


  const panel1 = $(go.Panel, 'Horizontal', { height: 37 },
    $(go.Shape, 'Circle', {
      width: 10, height: 10, margin: 2, stroke: null,
    },
    new go.Binding('fill', 'navigationType', (type) => {
      if (type === 'red') {
        return '#F25C62';
      }
      if (type === 'green') {
        return '#21C695';
      }
      return '#3D80FF';
    })),
    $(go.TextBlock, '前往', {
      margin: 5, stroke: '#6B8093', font: 'normal 14px PingFangSC-Regular',
    }),
    new go.Binding('visible', 'parent', parent => parent && parent !== 'GeneralQRoot' && parent !== 'RobotQRoot'));

  const panel2 = $(go.Panel, 'auto', {},
    $(go.Shape, {
      name: 'Q_SHAPE', height: 34, fill: normalFillColor, stroke: normalStrokeColor, strokeWidth,
    },
    new go.Binding('width', 'parent', (parent) => {
      if (parent && parent !== 'GeneralQRoot' && parent !== 'RobotQRoot') {
        return 100;
      }
      return 170;
    }),
    new go.Binding('geometry', 'parent', (parent) => {
      if (parent && parent !== 'GeneralQRoot' && parent !== 'RobotQRoot') {
        return geo;
      }
      return geo2;
    }),
    new go.Binding('visible', 'isleaf', isleaf => !isleaf)),
    $(go.TextBlock, 'BOT问名称', {
      name: 'Q_TEXT', font: 'normal 14px PingFangSC-Regular', wrap: go.TextBlock.WrapFit,
    },
    new go.Binding('desiredSize', 'parent', (parent) => {
      if (parent && parent !== 'GeneralQRoot' && parent !== 'RobotQRoot') {
        return new go.Size(100, 16);
      }
      return new go.Size(150, 16);
    }),
    new go.Binding('text', 'nodeName').makeTwoWay(),
    new go.Binding('margin', 'isleaf', (isleaf) => {
      if (isleaf) {
        return 0;
      }
      return new go.Margin(10, 0, 0, 14);
    }),
    new go.Binding('stroke', 'isleaf', (isleaf) => {
      if (isleaf) {
        return fontColorLeaf;
      }
      return fontColor;
    })));

  // eslint-disable-next-line
  const panel3 = $(go.Panel, 'auto', { margin: new go.Margin(0, 0, 0, -20), height: 15, width: 10 },
    $(go.Shape, 'Rectangle', {
      width: 4, height: 4, fill: '#C4CED8', strokeWidth: 0, margin: new go.Margin(0, 0, 0, 0),
    }),
    $(go.Shape, 'Rectangle', {
      width: 4, height: 4, fill: '#C4CED8', strokeWidth: 0, margin: new go.Margin(0, 0, 0, 5),
    }),
    $(go.Shape, 'Rectangle', {
      width: 4, height: 4, fill: '#C4CED8', strokeWidth: 0, margin: new go.Margin(5, 0, 0, 0),
    }),
    $(go.Shape, 'Rectangle', {
      width: 4, height: 4, fill: '#C4CED8', strokeWidth: 0, margin: new go.Margin(5, 0, 0, 5),
    }),
    $(go.Shape, 'Rectangle', {
      width: 4, height: 4, fill: '#C4CED8', strokeWidth: 0, margin: new go.Margin(10, 0, 0, 0),
    }),
    $(go.Shape, 'Rectangle', {
      width: 4, height: 4, fill: '#C4CED8', strokeWidth: 0, margin: new go.Margin(10, 0, 0, 5),
    }),
    new go.Binding('visible', 'parent', parent => parent === 'GeneralQRoot' || parent === 'RobotQRoot'));

  const panel4 = $(go.Panel, 'auto', { height: 17, width: 16 },
    new go.Binding('margin', 'parent', (parent) => {
      if (parent && parent !== 'GeneralQRoot' && parent !== 'RobotQRoot') {
        return new go.Margin(0, 0, 0, -10);
      }
      return new go.Margin(0, -8, 0, 0);
    }),
    $(go.Panel, 'auto', {},
      new go.Binding('visible', 'isHighlighted').ofObject(),
      $('TreeExpanderCircleButton')));
  const panel = $(go.Panel, 'Horizontal',
    new go.Binding('margin', 'parent', (parent) => {
      if (parent && parent !== 'GeneralQRoot' && parent !== 'RobotQRoot') {
        return 0;
      }
      return new go.Margin(0, 0, 0, 10);
    }),
    $(go.Panel, 'Horizontal', {}, panel1, panel2, panel3, panel4));
  panel.mouseEnter = (e, obj) => {
    setNodeColor(obj, 'Q_SHAPE', hoverStrokeColor, hoverFillColor);
  };
  panel.mouseLeave = (e, obj) => {
    setNodeColor(obj, 'Q_SHAPE', normalStrokeColor, normalFillColor);
  };
  return panel;
});


go.GraphObject.defineBuilder('AnswerTypeNode', () => {
  const normalStrokeColor = '#C4CED8';
  const normalFillColor = '#E7ECF0';

  const hoverStrokeColor = '#B0CCFF';
  const hoverFillColor = '#E7ECF0';

  const fontColor = '#6B8093';

  const panel = $(go.Panel, 'Horizontal', {},
    $(go.Panel, 'auto', {},
      $(go.Panel, 'auto', { height: 37 },
        $(go.Shape, 'Border', {
          name: 'ASW_SHAPEBORDER', margin: 0, width: 30, height: 36, stroke: normalStrokeColor, strokeWidth: 3, fill: normalStrokeColor,
        }),
        $(go.Shape, 'Border', {
          name: 'ASW_SHAPE', margin: new go.Margin(0, 0, 0, 3), width: 80, height: 36, stroke: normalStrokeColor, strokeWidth: 1, fill: normalFillColor,
        }),
        new go.Binding('visible', 'isleaf', isleaf => !isleaf)),
      $(go.TextBlock, 'default text', {
        name: 'ASW_TEXT', margin: 12, stroke: fontColor, font: 'normal 14px PingFangSC-Regular',
      },
      new go.Binding('text', 'nodeName'))),
    $(go.Panel, 'auto', { margin: new go.Margin(0, 0, 0, -15), height: 15, width: 10 },
      $(go.Shape, 'Rectangle', {
        width: 4, height: 4, fill: '#C4CED8', strokeWidth: 0, margin: new go.Margin(0, 0, 0, 0),
      }),
      $(go.Shape, 'Rectangle', {
        width: 4, height: 4, fill: '#C4CED8', strokeWidth: 0, margin: new go.Margin(0, 0, 0, 5),
      }),
      $(go.Shape, 'Rectangle', {
        width: 4, height: 4, fill: '#C4CED8', strokeWidth: 0, margin: new go.Margin(5, 0, 0, 0),
      }),
      $(go.Shape, 'Rectangle', {
        width: 4, height: 4, fill: '#C4CED8', strokeWidth: 0, margin: new go.Margin(5, 0, 0, 5),
      }),
      $(go.Shape, 'Rectangle', {
        width: 4, height: 4, fill: '#C4CED8', strokeWidth: 0, margin: new go.Margin(10, 0, 0, 0),
      }),
      $(go.Shape, 'Rectangle', {
        width: 4, height: 4, fill: '#C4CED8', strokeWidth: 0, margin: new go.Margin(10, 0, 0, 5),
      }),
      new go.Binding('visible', 'isleaf', isleaf => !isleaf)),
    $(go.Panel, 'auto', { margin: new go.Margin(0, -5, 0, -4), height: 17, width: 16 },
      $(go.Panel, 'Horizontal', {},
        new go.Binding('visible', 'isHighlighted').ofObject(),
        $('TreeExpanderCircleButton'))));

  panel.mouseEnter = (_, obj) => {
    setNodeColor(obj, 'ASW_SHAPE', hoverStrokeColor, hoverFillColor);
    setNodeColor(obj, 'ASW_SHAPEBORDER', hoverStrokeColor, hoverStrokeColor);
  };
  panel.mouseLeave = (_, obj) => {
    setNodeColor(obj, 'ASW_SHAPE', normalStrokeColor, normalFillColor);
    setNodeColor(obj, 'ASW_SHAPEBORDER', normalStrokeColor, normalStrokeColor);
  };
  return panel;
});
