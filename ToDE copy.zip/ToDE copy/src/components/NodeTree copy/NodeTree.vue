<template>
  <div class="node-tree-wrapper">
    <div id="tasksDiagram" class="digram-canvas"></div>
  </div>
</template>

<script>
import go from 'gojs';
import './GoBuilders';

const $ = go.GraphObject.make;
const TASKS = require('./initialstruc.json');

const NODETYPES = {
  QUESTION: 'QUESTION',
  ANSWERTYPE: 'ANSWERTYPE',
  FUNCTION: 'FUNCTION',
};
const FUNCTION_NODE_KEYS = {
  AddBotQ: 'AddBotQ',
  AddGeneralQ: 'AddGeneralQ',
  GapNode: 'GapNode',
  XLine: 'XLine',
  YLine: 'YLine',
  GeneralQRoot: 'GeneralQRoot',
  RobotQRoot: 'RobotQRoot',
};
const AddBtnTitle = {
  AddBotQ: '+新增BOT问',
  AddGeneralQ: '+新增情景'
}
export default {
  data: {
    tasksDiagram: null,
    selectedNode: null,
    nodesArray: [],
  },
  props: {
    nodes: {
      type: Array,
      default: [],
    },
    defaultSelectNode: {
      type: String,
      default: 'entry'
    }
  },
  mounted() {
    this.generateChart();
  },
  watch: {
    nodes() {
      this.generateChart();
    },
  },
  methods: {
    generateChart() {
      this.nodesArray = TASKS.concat(this.nodes);
      this.nodesArray.forEach((item) => {
        // item.funcChangeTitle = new Function('textblock', 'oldStr', 'newStr', "alert('hahah')");
        if (item.nodeType === NODETYPES.FUNCTION) {
          item.funcChangeTitle = this.handleAddNewNode;
        }
      });
      this.generateDiagram('tasksDiagram', this.nodesArray);
    },
    // 输入BOT问名字|情景名字之后回车保存，新增结点
    handleAddNewNode(textblock, oldStr, newStr) {
      // 把名字改回来
      let addBtnKey = '';
      if (oldStr === AddBtnTitle.AddBotQ) {
        addBtnKey = 'AddBotQ';
        // this.addQuestionNode(FUNCTION_NODE_KEYS.RobotQRoot, newStr);
        this.$emit('clickAddBotQ', newStr);
        const AddBotQ = this.tasksDiagram.findNodeForKey('AddBotQ');
        this.tasksDiagram.model.setDataProperty(AddBotQ.data, 'nodeName', AddBtnTitle.AddBotQ);
      } else if (oldStr === AddBtnTitle.AddGeneralQ) {
        addBtnKey = 'AddGeneralQ';
        const AddGeneralQ = this.tasksDiagram.findNodeForKey('AddGeneralQ');
        this.tasksDiagram.model.setDataProperty(AddGeneralQ.data, 'nodeName', AddBtnTitle.AddGeneralQ);
        // this.addQuestionNode(FUNCTION_NODE_KEYS.GeneralQRoot, newStr);
        this.$emit('clickAddGeneralQ', newStr);
      } else {
        return;
      }
      const node = this.tasksDiagram.findNodeForKey(addBtnKey);
      if (!node) {
        return;
      }
    },
    generateDiagram(id, dataArray) {
      // 创建图表对象
      const diagram = $(go.Diagram, id, {
        'animationManager.isEnabled': true,
        maxSelectionCount: 1,
        allowSelect: true,
        allowZoom: false,
        contentAlignment: go.Spot.TopLeft,
        allowHorizontalScroll: true,
        allowVerticalScroll: true,
        scrollMode: go.Diagram.DocumentScroll,
        validCycle: go.Diagram.CycleDestinationTree,
        hasHorizontalScrollbar: false,
        hasVerticalScrollbar: false,
        layout: $(go.TreeLayout, {
          angle: 0,
          layerSpacing: 20,
          nodeSpacing: 5,
          nodeIndentPastParent: 10,
          rowIndent: 200,
        }),
        'undoManager.isEnabled': true,
        padding: new go.Margin(67, 0, 0, -30),
        click: this.handleClickBackground,
        mouseDrop: this.handleDropNode2Background,
        TreeExpanded: () => {
          this.resetFunctionNodes();
        },
        TreeCollapsed: () => {
          this.resetFunctionNodes();
        },
        LayoutCompleted: () => {
          this.createFunctionNodes();
          diagram.animationManager.isEnabled = true;
        },
      });

      // 创建结点模板
      diagram.nodeTemplate = $(go.Node, 'Horizontal', {
        mouseDragEnter: this.nodeMouseDragEnter,
        mouseDragLeave: this.nodeMouseDragLeave,
        mouseDrop: this.nodeMouseDrop,
        mouseEnter: (e, node) => {
          node.isHighlighted = true;
        },
        mouseLeave: (e, node) => {
          node.isHighlighted = false;
        },
        click: this.handleClickNode,
        selectionAdorned: false,
      },
      // 保证选中的结点在最上层Center
      new go.Binding('layerName', 'isSelected', (sel) => {
        let layer = '';
        if (sel) {
          layer = 'Foreground';
        }
        return layer;
      }).ofObject(),
      $('FunctionNode', new go.Binding('visible', 'nodeType', type => type === NODETYPES.FUNCTION)),
      $('QuestionNode', new go.Binding('visible', 'nodeType', type => type === NODETYPES.QUESTION)),
      $('AnswerTypeNode', new go.Binding('visible', 'nodeType', type => type === NODETYPES.ANSWERTYPE)));


      // 创建结点间连线
      diagram.linkTemplate = $(go.Link, {
        routing: go.Link.Orthogonal,
        corner: 5,
        selectionAdorned: false,
      }, $(go.Shape, { strokeWidth: 1, width: 0 }, new go.Binding('stroke', 'navigationType', (navigationType) => {
        let color = '#C4CED8';
        if (navigationType === 'red') {
          color = '#F25C62';
        } else if (navigationType === 'green') {
          color = '#21C695';
        } else if (navigationType === 'blue') {
          color = '#3D80FF';
        }
        return color;
      }), new go.Binding('strokeDashArray', 'navigationType', (navigationType) => {
        let dash = null;
        if (navigationType && navigationType !== '') {
          dash = [4, 4, 4, 4];
        }
        return dash;
      })));

      // 创建背景连线
      diagram.nodeTemplateMap.add(FUNCTION_NODE_KEYS.YLine,
        $(go.Node, 'Spot', {
          layerName: 'Foreground',
          selectable: false,
          isLayoutPositioned: false,
          locationSpot: go.Spot.TopLeft,
        },
        $(go.Shape, 'MinusLine', {
          strokeWidth: 1, stroke: '#E9E9E9', angle: 90,
        })));
      diagram.nodeTemplateMap.add(FUNCTION_NODE_KEYS.XLine,
        $(go.Node, 'Spot', {
          layerName: 'Foreground',
          selectable: false,
          isLayoutPositioned: false,
          locationSpot: go.Spot.TopLeft,
          // location: new go.Point(0, -100)
        },
        $(go.Shape, 'MinusLine', {
          strokeWidth: 1, stroke: '#E9E9E9', angle: 0, height: 0,
        })));
      // 创建Diagram的Data Model
      const model = $(go.TreeModel);
      model.nodeDataArray = dataArray;
      diagram.model = model;
      this.tasksDiagram = diagram;
    },
    // 初始化X轴Y轴的位置和长度，已经功能性结点【新增BOT问】【新增情景】等的位置
    resetFunctionNodes() {
      const yLine = this.tasksDiagram.findNodeForKey(FUNCTION_NODE_KEYS.YLine);
      // yLine.location = new go.Point(0,0);
      yLine.height = 0;
      const xLine = this.tasksDiagram.findNodeForKey(FUNCTION_NODE_KEYS.XLine);
      xLine.width = 0;
      const generalG1 = this.tasksDiagram.findNodeForKey(FUNCTION_NODE_KEYS.GapNode);
      generalG1.height = 34;
    },
    // 根据图表大小设置X轴Y轴的位置和长度，已经功能性结点【新增BOT问】【新增情景】等的位置
    createFunctionNodes() {
      const diagramMarginLeft = 30;
      const diagram = this.tasksDiagram;
      const canvasHeight = diagram.documentBounds.Y;
      const canvasWidth = diagram.documentBounds.$;
      const boxHeight = diagram.viewportBounds.Y;
      const boxWidth = diagram.viewportBounds.$;

      // 设置【Bot问】树和【全局通用问题设定】树之间的距离
      const generalG1 = diagram.findNodeForKey(FUNCTION_NODE_KEYS.GapNode);
      const generalY = generalG1.position.D;
      if (generalY < boxHeight - 260) {
        const posY = boxHeight - 235 - generalY;
        generalG1.height = posY;
      }

      // 设置纵向坐标轴-YLine的位置和高度
      const yLine = diagram.findNodeForKey(FUNCTION_NODE_KEYS.YLine);
      yLine.location = new go.Point(162 + diagramMarginLeft, 0);
      yLine.height = (boxHeight > canvasHeight ? boxHeight - 70 : canvasHeight - 50);

      // 设置横向坐标轴-XLine的位置和长度
      const xLine = diagram.findNodeForKey(FUNCTION_NODE_KEYS.XLine);
      const generalHeight = generalG1.height ? generalG1.height : 34;
      xLine.location = new go.Point(diagramMarginLeft, generalY + generalHeight - 5);
      xLine.width = boxWidth > canvasWidth ? boxWidth : canvasWidth;
      // xLine.height =  500;
    },
    // 当用户拖拽结点到图表背景时
    handleDropNode2Background(e) {
      const selNode = e.diagram.selection.first();
      const xPos = selNode.position.C;
      // 把子节点拖拽到1级结点
      if (xPos <= 65 && selNode.data.parent !== FUNCTION_NODE_KEYS.RobotQRoot) {
        // 从第2，3...级拖拽到第1级
        this.tasksDiagram.model.setParentKeyForNodeData(selNode.data,
          FUNCTION_NODE_KEYS.RobotQRoot);
      } else {
        const newNodeDataArray = this.dragBetweenSiblings(selNode);
        if (newNodeDataArray) {
          this.tasksDiagram.animationManager.isEnabled = false;
          const model = $(go.TreeModel);
          model.nodeDataArray = newNodeDataArray;
          this.tasksDiagram.model = model;
        } else {
          this.cancelNodeDrag();
        }
        // 兄弟结点之间的拖拽
      }
    },
    dragBetweenSiblings(selNode) {
      const sibNodes = selNode.findTreeParentNode().findTreeChildrenNodes();
      // 拖拽的结点的坐标范围
      const selNodeRect = {
        minX: selNode.wb.C,
        maxX: selNode.wb.C + selNode.wb.$,
        minY: selNode.wb.D,
        maxY: selNode.wb.D + selNode.wb.Y,
      };
      // 拖拽中的结点的Y轴中位线
      const nodePosY = (selNode.wb.y * 2 + selNode.wb.Y) / 2;
      // 记录拖拽的结点所在子树的坐标范围
      const treeRect = {
        minX: Number.MAX_VALUE,
        maxX: Number.MIN_VALUE,
        minY: Number.MAX_VALUE,
        maxY: Number.MIN_VALUE,
      };
      let newOrder = 0;
      // 根据y的位置排序，算出子树的区域
      sibNodes.each((sib) => {
        if (sib.data.key !== selNode.data.key) {
          treeRect.minX = treeRect.minX < sib.wb.C ? treeRect.minX : sib.wb.C;
          treeRect.maxX = treeRect.maxX > sib.wb.C + sib.wb.$ ? treeRect.maxX : sib.wb.C + sib.wb.$;
          treeRect.minY = treeRect.minY < sib.wb.D ? treeRect.minY : sib.wb.D;
          treeRect.maxY = treeRect.maxY > sib.wb.D + sib.wb.Y ? treeRect.maxY : sib.wb.D + sib.wb.Y;
          if (nodePosY > (sib.wb.D * 2 + sib.wb.Y) / 2) {
            newOrder += 1;
          }
        }
      });
      // 如果拖拽超出了子树范围，则取消拖拽
      if (selNodeRect.minX < treeRect.minX - 50
        || selNodeRect.minY < treeRect.minY - 200
        || selNodeRect.maxX > treeRect.maxX + 50
        || selNodeRect.maxY > treeRect.maxY + 200) {
        return false;
      }
      // 判断是否超出子树区域
      // 判断index是否发生了改变
      let tmpIndex = 0;
      let insertIndex = 0;
      let oldIndex = 0;
      const nodeData = this.tasksDiagram.model.nodeDataArray.slice(0);
      nodeData.forEach((value, index) => {
        if (value.parent === selNode.data.parent) {
          if (tmpIndex === newOrder) {
            insertIndex = index;
            if (value.key === selNode.data.key) {
              insertIndex = -1;
            }
          }
          if (value.key === selNode.data.key) {
            oldIndex = index;
          }
          tmpIndex += 1;
        }
      });
      if (insertIndex === -1) {
        return false;
      }
      const item = nodeData.splice(oldIndex, 1);
      nodeData.splice(insertIndex, 0, item[0]);
      return nodeData;
    },
    // 取消图表的拖拽操作
    cancelNodeDrag() {
      this.tasksDiagram.currentTool.doCancel();
    },
    verifyReconnect(toNode, selectNode) {
      if (toNode === selectNode) {
        return false;
      }
      // 只能将问题结点拖拽到回答类型结点
      if (selectNode.data.nodeType !== NODETYPES.QUESTION
        || toNode.data.nodeType !== NODETYPES.ANSWERTYPE) {
        return false;
      }
      // 不能拖拽到子结点上
      if (toNode.isInTreeOf(selectNode)) {
        return false;
      }
      return true;
    },
    // 把其他结点拖拽到当前结点的位置时
    nodeMouseDragEnter(e, node) {
      const { diagram } = node;
      const selnode = diagram.selection.first();
      // 判断是否能够拖拽
      if (!this.verifyReconnect(node, selnode)) {
        return;
      }
      this.setNodeColor(node, '#3D80FF', '#FFFFFF');
    },
    // 把其他结点拖拽到当前结点的位置后脱离开时
    nodeMouseDragLeave(e, node) {
      const { diagram } = node;
      const selnode = diagram.selection.first();
      if (!this.verifyReconnect(node, selnode)) {
        return;
      }
      this.setNodeColor(node, '#E7ECF0', '#6B8093');
    },
    // 某个结点被丢在当前结点上时
    nodeMouseDrop(e, node) {
      const { diagram } = node;
      const selnode = diagram.selection.first();
      if (!this.verifyReconnect(node, selnode)) {
        this.cancelNodeDrag();
        return;
      }
      const link = selnode.findTreeParentLink();
      if (link !== null) {
        // relink an existing link
        link.fromNode = node;
      } else {
        // create a new link
        diagram.toolManager.linkingTool.insertLink(node, node.port, selnode, selnode.port);
      }
      this.resetFunctionNodes();
    },
    setNodeColor(node, shapeFillColor, textColor) {
      if (node.data.nodeType === NODETYPES.ANSWERTYPE) {
        node.findObject('ASW_SHAPE').fill = shapeFillColor;
        node.findObject('ASW_SHAPE').stroke = '#C4CED8';
        node.findObject('ASW_TEXT').stroke = textColor;
      } else {
        node.findObject('Q_SHAPE').fill = shapeFillColor;
        node.findObject('Q_SHAPE').stroke = '#E7ECF0';
        node.findObject('Q_TEXT').stroke = textColor;
      }
    },
    handleClickNode(e, node) {
      console.log(`handleClickNode --- ${node.data.key}`);
      // 点击子结点无响应
      if (node.data.isleaf) {
        return;
      }
      // 点击功能结点
      if (node.data.nodeType === NODETYPES.FUNCTION) {
        return;
      }
      if (this.selectedNode) {
        this.setNodeColor(this.selectedNode, '#E7ECF0', '#6B8093');
      }
      this.selectedNode = node;
      this.setNodeColor(node, '#3D80FF', '#FFFFFF');
      this.$emit('select', node.data);
    },
    handleClickBackground() {
      // if (this.selectedNode && this.selectedNode.data.isleaf) {
      //   return;
      // }
      // if (this.selectedNode) {
      //   this.setNodeColor(this.selectedNode, '#E7ECF0', '#6B8093');
      // }
      // this.selectedNode = null;
    },
    /*
    * 对外接口 - Open API List
    */
    // 封装【增删改查】
    // API - 新增BOT问 || 情景问
    apiAddBotQNode(nodeId, nodeName, parentId, colorType, isGlobal, isLeaf) {
      let parentNodeId = parentId;
      if (!parentNodeId) {
        parentNodeId = isGlobal ? 'GeneralQRoot' : 'RobotQRoot';
      }
      const newNode = {
        key: nodeId,
        nodeName: nodeName,
        parent: parentNodeId,
        navigationType: colorType,
        nodeType: NODETYPES.QUESTION,
        isleaf: isLeaf,
      };
      const node = this.addNewNode(newNode);
      this.$nextTick(() => {
        this.handleClickNode(null, node);
      });
    },
    // 删除BOT问题
    apiRemoveBotQNode(nodeId) {
      const nodeData = this.tasksDiagram.model.findNodeDataForKey(nodeId);
      if (nodeData && nodeData.key) {
        this.removeNode(nodeData);
      }
    },
    // 修改BOT问题结点的名称
    apiChangeNodeTitle(title) {
      this.tasksDiagram.startTransaction('change a node');
      this.tasksDiagram.model.setDataProperty(this.selectedNode.data, 'nodeName', title);
      this.tasksDiagram.commitTransaction('change a node');
    },
    // 修改BOT问题结点名称
    apiChangeNodeTitle2(nodeId, title) {
      this.tasksDiagram.startTransaction('change a node');
      const data = this.tasksDiagram.model.findNodeDataForKey(nodeId);
      this.tasksDiagram.model.setDataProperty(data, 'nodeName', title);
      this.tasksDiagram.commitTransaction('change a node');
    },
    // 新增回答类型结点
    apiAddAnswerNode(questionId, answerType) {
      const newNode = {
        key: `${questionId}-${answerType}`,
        parent: questionId,
        navigationType: '',
        nodeType: NODETYPES.ANSWERTYPE,
        nodeName: answerType,
        isleaf: false,
      };
      this.addNewNode(newNode)
    },
    // 删除回答类型结点
    apiRemoveAnswerNode(questionId, answerType) {
      const nodeData = this.tasksDiagram.model.findNodeDataForKey(`${questionId}-${answerType}`);
      if (nodeData && nodeData.key) {
        this.removeNode(nodeData);
      }
    },
    addNewNode(nodeData) {
      this.tasksDiagram.startTransaction('add a node');
      this.tasksDiagram.model.addNodeData(nodeData);
      this.tasksDiagram.commitTransaction('add a node');
      const node = this.tasksDiagram.findNodeForData(nodeData);
      this.tasksDiagram.commandHandler.scrollToPart(node);
      return node;
    },
    removeNode(nodeData) {
      this.tasksDiagram.startTransaction('remove a node');
      this.tasksDiagram.model.removeNodeData(nodeData);
      this.tasksDiagram.commitTransaction('remove a node');
    },
  },
};
</script>

<style lang="scss">
@import "../../assets/scss/style";
.node-tree-wrapper{
  width: 100%;
  height: 100%;
  .digram-canvas{
    width: 100%;
    height: calc(100% + 17px);
    margin-top: -17px;
    canvas{
      outline: none;
    }
  }
}
</style>
