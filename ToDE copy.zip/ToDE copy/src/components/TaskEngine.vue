<template>
  <div class="task-engine-wrapper">
    <task-engine-list v-if="taskId === ''" @toDetail="navigateToDetail"></task-engine-list>
    <task-engine-detail v-else @back="handleBackToList"
    :scenarioId="taskId" :scenarioName="taskName" :scenarioEnabled="taskEnabled"></task-engine-detail>
  </div>
</template>

<script>
import TaskEngineList from './TaskEngineList';
import TaskEngineDetail from './TaskEngineDetail';

export default {
  path: 'task-engine',
  name: 'task-engine',
  data() {
    return {
      taskId: '招商信诺回访',
      taskName: '招商信诺回访',
      taskEnabled: false,
    };
  },
  methods: {
    navigateToDetail(id, name, enabled) {
      this.taskId = id;
      this.taskName = name;
      this.taskEnabled = enabled;
    },
    handleBackToList() {
      this.taskId = '';
      this.taskName = '';
      this.taskEnabled = false;
    },
  },
  components: {
    TaskEngineList,
    TaskEngineDetail,
  },
};
</script>

<style lang="scss" scoped>
@import "../assets/scss/style";
.task-engine-wrapper{
  overflow: hidden;
  @extend .white-panel;
  height: calc(100% - 40px) !important;
  font-family:PingFangHK-Regular;
  font-weight:400;
}
</style>
