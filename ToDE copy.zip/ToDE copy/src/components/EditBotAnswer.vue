<template>
  <div class="edit-answer-wrapper">
    <div class="header">
      <span>用户回答问题-{{BOTAnswer.type}}</span>
      <img src="../assets/images/delete_b.png">
    </div>
    <div class="add-navigation-wrapper">
      <span class="add-nav-title">用户回答后机器人行为</span>
      <span class="add-nav-btn" @click="handleAddNavigation">+新增</span>
    </div>
    <div class="error-info">
        <i class="el-icon-warning error-icon"></i>
        <span>条件未设置完整</span>
    </div>
    <div v-for="item in BOTAnswer.navigations">
       <edit-answer-nav class="nav-box" :NAV="item" @createRelevantNode="handleCreateRelevantNode"
       @delete="handleDeleteNavigation" @add2Node="handleAddNavigate2Node"
       @delete2Node="handleDeleteNavigate2Node" @update2Node="handleUpdateNavigate2Node"
       :currentNodeList="nodeList" :currentNodeMap="nodeMap"></edit-answer-nav>
    </div>
  </div>
</template>

<script>
import EditAnswerNav from './EditAnswerNav';

export default {
  props: {
    BOTAnswer: {
      type: Object,
      default() {
        return {
          type: '告知',
          enabled: true,
          operator: 'and',
          navigations: [
            {
              action: {
                assginment: {
                  target: 'val_city',
                  value: '$city',
                },
                navigateTo: {
                  nodeId: '84212722430002',
                  nodePresetTexts: '重复话术'
                },
                textReply: '确定城市为city...',
                webApi: '001',
              },
              conditions: [
                {
                  operator: '>',
                  param1: 'city',
                  param2type: 'variant',
                  param2value: 'city',
                }
              ],
            }
          ],
        };
      },
    },
    nodeList: {
      type: Array,
    },
    nodeMap: {
      type: Object,
    }
  },
  create() {
    if (this.nodeList) {
      console.log(`this.nodeList = ${this.nodeList}`);
    }
  },
  watch: {
    nodeList() {
      if (this.nodeList) {
        console.log(`this.nodeList = ${this.nodeList}`);
      }
    }
  },
  methods: {
    handleCreateRelevantNode(botNav) {
      this.$emit('createRelevantNode', this.BOTAnswer, botNav);
    },
    handleAddNavigation() {
      if (!this.BOTAnswer.navigations || !this.BOTAnswer.navigations instanceof Array) {
        this.BOTAnswer.navigations = [];
      }
      const newNav = {
        navId: `nav-${Math.random().toString(36).substr(2)}`,
        action: {
          otherActions: [],
          navigateTo: {
            nodeId: '',
            nodePresetTexts: ''
          },
        },
        conditions: [],
        operator: 'or',
      };
      this.BOTAnswer.navigations.push(newNav);
    },
    handleDeleteNavigation(nav) {
      this.$emit('deleteNavigation', this.BOTAnswer, nav.navId, null, null);
      const index = this.BOTAnswer.navigations.indexOf(nav);
      this.BOTAnswer.navigations.splice(index, 1);
    },
    handleAddNavigate2Node(nav, toNodeId, pretext) {
      this.$emit('addNavigation', this.BOTAnswer, nav.navId, toNodeId, pretext);
    },
    handleDeleteNavigate2Node(nav, toNodeId, pretext) {
      this.$emit('deleteNavigation', this.BOTAnswer, nav.navId, toNodeId, pretext);
    },
    handleUpdateNavigate2Node(nav, oldNode, newNode, pretext) {
      this.$emit('updateNavigation', this.BOTAnswer, nav.navId, oldNode, newNode, pretext);
    },
  },
  components: {
    EditAnswerNav,
  }
};
</script>

<style lang="scss" scoped>
@import "../assets/scss/style";
.edit-answer-wrapper{
  font-size: 12px;
  padding-bottom: 10px;
  .header{
    height:50px;
    background:rgba(247,247,247,1);
    box-shadow:0px 1px 0px 0px rgba(233,233,233,1);
    display: flex;
    align-items: center;
    padding: 0px 20px;
    span{
      font-size: 16px;
      font-weight: 500;
      color: #333333;
      flex: 1;
    }
    img{
      width: 24px;
      cursor: pointer;
    }
  }
  .add-navigation-wrapper{
    padding: 10px 20px;
    display: flex;
    span{
      line-height: 20px;
      height: 20px;
    }
    .add-nav-title{
      color: #999999;
      flex: 1;
    }
    .add-nav-btn{
      color: #333333;
      cursor: pointer;
    }
  }
  .error-info{
    background:rgba(255,255,255,1);
    border-radius:2px;
    border:1px solid rgba(233,233,233,1);
    margin: 0px 10px 10px 10px;
    padding: 10px;
    .error-icon{
      font-size: 16px;
      color: #F76260;
    }
    span{
      line-height: 16px;
      height: 16px;
      margin-left: 6px;
      vertical-align: top;
    }
  }
  .nav-box{
    margin: 10px 10px 0px 10px;
  }
}
</style>
