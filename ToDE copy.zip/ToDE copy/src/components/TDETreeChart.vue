<template>
  <div class="node-tree-chart">
    <node-tree ref="tasksTreeDiagram" :nodes="nodeTreeData" @select="handleNodeSelected"></node-tree>
  </div>
</template>

<script>
import NodeTree from './NodeTree/NodeTree';
export default {
  props: {
    // 场景Detail数据（Json格式）
    taskDetailsJson: {
      type: Object,
    }
  },
  created() {
    this.generateTreeDataByJson(this.taskDetailsJson);
  },
  data() {
    return {
      nodeTreeData: [],
      scenarioDetailMap: {},
    }
  },
  methods: {
    handleNodeSelected() {
      alert('handleNodeSelected');
    },
    // 通过后台返回的场景Json数据，生成node-tree组件的结点数组
    // 存入【scenarioNodesMap】和【nodeTreeData】中
    generateTreeDataByJson(detailJson) {
      const res = [];
      // 场景入口结点
      const { entry } = detailJson;
      if (entry) {
        res.push({
          key: 'entry',
          parent: 'RobotQRoot',
          nodeType: 'QUESTION',
          navigationType: '',
          nodeName: '场景入口',
          isleaf: false,
        });
      }
      // BOT问结点
      const { nodeList } = detailJson;
      // 创建node_id -> node_value的map
      if (nodeList instanceof Array) {
        nodeList.forEach((item) => {
          this.scenarioDetailMap[item.nodeId] = item;
        });
      }
      nodeList.forEach((item) => {
        if (item.isRelevant === false && item.nodeId !== 'exit') {
          const parentId = item.isGlobal ? 'GeneralQRoot' : 'RobotQRoot';
          this.genereateTreeNodeData(parentId, null, item.nodeId, null, false, res, '');
        }
      });
      this.nodeTreeData = res;
    },
    genereateTreeNodeData(parentId, parentType, nodeId, nodePresetText, isNodeExisted, targetArray, navId) {
      const nodeData = this.scenarioDetailMap[nodeId];
      if (!nodeData) {
        return;
      }
      const treeNode = {
        key: nodeId,
        parent: parentId,
        nodeType: 'QUESTION',
        navigationType: 'green', // '', 'green', 'red', 'blue';
        nodeName: nodeData.title,
        isleaf: false,
        data: nodeData
      };

      if (`${nodeId}-${parentType}` === parentId) {
        // 当前结点是parent结点，如：前往[重复问]|[解析失败]等话术
        treeNode.key = `${parentId}-${navId}`;
        treeNode.isleaf = true;
        treeNode.nodeName = `[${nodePresetText}]`;
        if (nodePresetText === '解析失败') {
          treeNode.navigationType = 'red';
        } else {
          treeNode.navigationType = 'blue';
        }
      } else if (nodeData.isRelevant === false) {
        // 当前结点是一级结点，非关联结点
        if (parentId === 'GeneralQRoot' || parentId === 'RobotQRoot') {
          // 添加一级结点，如[确认本人]或[退出对话]
          treeNode.navigationType = '';
        } else {
          // 前往一级结点，如：前往[是否方便]
          treeNode.key = `${parentId}-${navId}`;
          treeNode.isleaf = true;
          if (nodeId !== 'exit') {
            treeNode.nodeName = `[${treeNode.nodeName}]`;
          } 
          treeNode.navigationType = 'green';
        }
      } else if (nodeData.isRelevant) {
        treeNode.navigationType = 'green';
        // 关联问是否被添加到关联的问题下
        if (nodeData.relevantParent && `${nodeData.relevantParent.nodeId}-${nodeData.relevantParent.answerType}` === parentId) {
          treeNode.isleaf = false;
        } else {
          // 当前是关联结点,如：前往提供新号码，Hover可展开
          treeNode.isleaf = true;
        }
      }
      if (nodeId === 'exit') {
        treeNode.navigationType = 'red';
        treeNode.nodeName = treeNode.nodeName;
      }
      // 添加问题结点
      targetArray.push(treeNode);

      if (treeNode.isleaf) {
        return;
      }
      if (nodeData.answerTypes instanceof Array) {
        nodeData.answerTypes.forEach((item) => {
          if (!item.enabled) {
            return;
          }
          // 添加当前回答类型结点
          const answerNode = {
            key: `${nodeId}-${item.type}`,
            parent: nodeId,
            nodeType: 'ANSWERTYPE',
            navigationType: '', // '', 'green', 'red', 'blue';
            nodeName: item.type,
            isleaf: false,
            data: item
          };
          targetArray.push(answerNode);
          if (item.navigations instanceof Array) {
            item.navigations.forEach((nav) => {
              const toNodeId = nav.action && nav.action.navigateTo && nav.action.navigateTo.nodeId;
              if (toNodeId) {
                const id = `${nodeId}-${item.type}`;
                const pre = nav.action.navigateTo.nodePresetTexts;
                const exist = nav.action.navigateTo.alreadyExist;
                this.genereateTreeNode(id, item.type, toNodeId, pre, exist, targetArray, nav.navId);
              }
            });
          }
        });
      }
    },
  },
  components: {
    NodeTree,
  }
};
</script>

<style lang="scss" scoped>
@import "../assets/scss/style";
.node-tree-chart{
  width: 100%;
  height: 100%;
  background: yellow;
}
</style>
