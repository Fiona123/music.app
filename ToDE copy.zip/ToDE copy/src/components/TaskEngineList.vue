<template>
  <div class="task-engine-list-wrapper">
    <div v-if="scenariosList.length === 0" class="no-scenario-wrapper" >
      <div class="left-part">
        <h1>开始创建您的第一个多伦对话场景吧！</h1>
        <div class="links">
          <span>教学视频</span>
          <span>上传转换数据</span>
        </div>
        <div class="operations">
          <span class="btn-blue btn-big" @click="showCreateDlg=true">创建场景</span>
          <span class="btn-white-gray btn-big">导入场景</span>
        </div>
      </div>
      <div class="right-part">
        <img src="../assets/images/no_scenario.png">
      </div>
    </div>
    <div v-else class="scenario-list-wrapper">
      <div class="header">
        <h1>场景列表</h1>
        <el-input placeholder="输入文字"></el-input>
      </div>
      <div class="operations-box">
        <span class="btn-blue btn-medium" @click="showCreateDlg=true">创建场景</span>
        <span class="btn-white-gray btn-medium">导入场景</span>
        <span class="btn-white-gray btn-medium">导出全部场景</span>
        <label class="links">教学视频</label>
        <label class="links">上传转换数据</label>
      </div>
      <div class="scenario-list-box">
        <div class="scenario-box" v-for="item in scenariosList">
          <div class="header">
            <h1>{{item.taskName}}</h1>
            <div class="edit-box">
              <i class="el-icon-edit"></i>
            </div>
            <el-switch v-model="item.enable"></el-switch>
          </div>
          <div class="footer">
            <span class="normal-span">删除</span>
            <span class="normal-span">导出</span>
            <span class="emphasize-span btn-big" @click="handleEditScenario(item.taskId, item.taskName, item.enable)">编辑</span>
          </div>
        </div>
      </div>
    </div>
    <el-dialog :visible.sync="showCreateDlg" :show-close="false" title="场景创建" class="create-scenario-dialog">
      <div class="dlg-content">
        <div>
          <i class="el-icon-star-on"></i>
          <span>场景名称</span>
          <el-input v-model="inputScenarioName"></el-input>
        </div>
        <div>
          <span class="template-span">场景模板</span>
          <el-select v-model="inputScenarioTemplate">
            <el-option v-for="item in templates" :key="item.value" :label="item.label" :value="item.value">
          </el-option>
          </el-select>
        </div>
      </div>
      <span slot="footer">
        <button class="btn-white-gray btn-small" @click="showCreateDlg=false">取消</button>
        <button class="btn-dark-blue btn-small" @click="handleCreateScenario">确定创建</button>
      </span>
    </el-dialog>
    <base-loading class="loading-indicator" v-show="isLoading"></base-loading>
  </div>
</template>

<script>
import api from '../js/taskengineapi';

export default {
  data() {
    return {
      isLoading: true,
      scenariosList: [],
      showCreateDlg: false,
      inputScenarioName: '',
      inputScenarioTemplate: '',
      templates: [
        { value: '模板1', label: '模板1' },
        { value: '模板2', label: '模板2' },
      ],
    };
  },
  created() {
    this.getScenarioList();
  },
  methods: {
    // 获取场景列表
    getScenarioList() {
      this.isLoading = true;
      api.axiosGetScenarioList.call(this, this.appId, (list) => {
        this.scenariosList = list;
        this.isLoading = false;
      });
    },
    // 创建新的场景
    handleCreateScenario() {
      api.aioxsCreateScenario.call(this, this.appId,
        this.inputScenarioName, this.inputScenarioTemplate, (res) => {
          console.log(res);
          this.showCreateDlg = false;
          this.getScenarioList();
        });
    },
    // 编辑场景
    handleEditScenario(id, name, enabled) {
      this.$emit('toDetail', id, name, enabled);
    },
  },
};
</script>

<style lang="scss" scoped>
@import "../assets/scss/style";
.task-engine-list-wrapper{
  width: 100%;
  height: 100%;
  .loading-indicator{
    background: rgba(255, 255, 255, 0.5) !important;
  }
  .no-scenario-wrapper{
    width: 100%;
    height: 100%;
    display: flex;
    min-height: 590px;
    .left-part{
      flex: 8;
      height: 100%;
      display: flex;
      flex-direction: column;
      justify-content: center;
      font-family:PingFangHK-Regular;
      font-weight: 400;
      h1{
        margin: 0px 80px;
        font-size: 38px;    
        color: #333333;
        line-height:54px;
        letter-spacing:1px;
      }
      .links{
        margin: 20px 80px 40px 80px;
        cursor: pointer;
        span{
          font-size: 16px;
          color: #1875F0;
          line-height:24px;
          margin-right: 40px;
        }
      }
      .operations{
        margin: 0px 80px;
        cursor: pointer;
        span{
          margin-right: 20px;
          display: inline-block;
          vertical-align: middle;
        }
      }
    }
    .right-part{
      flex: 11;
      display: flex;
      align-items: center;
      img {
        width: 100%;
      }
    }
  }
  .scenario-list-wrapper{
    padding: 25px 20px;
    .header{
      display: flex;
      margin-bottom: 20px;
      h1{
        font-size:18px;
        color: #333333;
        line-height:24px;
        flex: 1;
      }
      .el-input{
        width: 220px;
        height: 32px;
        /deep/ input{
          height: 32px;
        }
      }
    }
    .operations-box{
      span{
        cursor: pointer;
        margin-right: 20px;
        height: 32px;
        line-height: 32px;
        display: inline-block;
      }
      label{
        cursor: pointer;
        float: right;
        font-size:14px; 
        line-height:24px;
        color: #1875F0;
        margin-left: 40px;
      }
    }
    .scenario-list-box{
      .scenario-box{
        float: left;
        margin: 20px 20px 0px 0px;
        width:370px;
        height:164px;
        border-radius:2px;
        border:1px solid rgba(233,233,233,1);
        padding: 30px;
        box-sizing: border-box;
        &:hover{
          .header{
            .edit-box{
              display: inline-block;
            }
          }
          .footer{
            .emphasize-span{
              @extend .btn-blue;
            }
          }
        }
        .header{
          h1{
            width: 228px;
            font-size: 16px;
            color: #333333;
            line-height:26px;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
          }
          .edit-box{
            display: none;
            width: 24px;
            height: 24px;
            border-radius: 100%;
            background:rgba(238,238,238,1);
            text-align: center;
            margin: 0px 20px 0px 16px;
            cursor: pointer;
            i{
              font-size: 16px;
              line-height: 24px;
              color: #6F7378;
            }
          }
          .el-switch{
            margin-top: 3px;
          }
        }
        .footer{
          display: flex;
          justify-content: flex-end;
          margin-top: 40px;
          span{
            display: inline-block;
            height: 38px;
            line-height: 38px;
            box-sizing: border-box;
          }
          .normal-span{
            width: 35px;
            margin-right: 30px;
            font-size:14px;
            color: #666666;
          }
          .emphasize-span{
            width: 100px;
            @extend .btn-white-gray;
          }
        }
      }
    }
  }
  .create-scenario-dialog{
    /deep/ .el-dialog{
      width: 650px;
    }
    /deep/ .el-dialog__header{
      box-shadow: 0px 1px 0px 0px rgba(233,233,233,1);
    }
    /deep/ .el-dialog__body{
      padding: 0px !important;
      box-shadow: 0px 1px 0px 0px rgba(233,233,233,1);
    }
    .dlg-content{
      padding: 50px 20px;
      >div{
        &:first-child{
          margin-bottom: 30px;
        }
        display: flex;
        >i{
          width: 12px;
          line-height: 32px;
          font-size: 8px;
          color: #F25C62;
          vertical-align: top;
        }
        span{
          margin-left: 10px;
          width: 56px;
          height: 32px;
          line-height: 32px;
          margin-right: 20px;
        }
        /deep/ .el-input{
          flex: 1;
          height: 32px;
          line-height: 32px;
          input{
            height: 32px;
            line-height: 32px;
          }
        }
        /deep/ .el-select{
          flex: 1;
          height: 32px;
          line-height: 32px;
        }
        .template-span{
          margin-left: 21px;
        }
      }
    }
  }
}
</style>
