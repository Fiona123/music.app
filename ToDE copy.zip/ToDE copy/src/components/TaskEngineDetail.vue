<template>
  <div class="scenarios-detail-wrapper">
    <div class="scenarios-detail-content">
      <div class="chart-box">
        <div class="hide-digram">
        </div>
        <div class="header">
          <h1>{{scenarioName}}</h1>
          <span class="subtitle">图例</span>
          <div class="bot-question-box"></div>
          <span>BOT问</span>
          <div class="user-box"></div>
          <span>用户</span>
          <div class="execution-box"></div>
          <span>BOT执行</span>
        </div>
        <div class="diagram-box">
          <tde-tree-chart :taskDetailsJson="scenarioDetailJson"></tde-tree-chart>
        </div>
      </div>
      <transition name="slide-fade">
        <div class="information-box" v-if="showInformationPanel">
          <div class="header">
            <img src="../assets/images/back.png" class="back-btn" @click="handleNavigateBack">
            <div class="task-name">
              <h1 v-if="!isEditingTaskName">{{scenarioName}}</h1>
              <el-input @change="handleChangeTaskName" v-model="scenarioDetailJson.taskName" class="tde-el-input" v-else></el-input>
            </div>
            <img class="edit-btn" src="../assets/images/edit_btn.png" @click="isEditingTaskName=!isEditingTaskName">
            <div class="expand-btn" >
              <div @click="expandInformationPanel">
                <img src="../assets/images/expand_btn.png">
              </div>
            </div>
          </div>
          <div class="operations">
            <span>开关</span><el-switch v-model="scenarioEnabled"></el-switch>
            <span>导出</span><img @click="handleExportTaskJson" width="64px" src="../assets/images/export_btn.png">
            <span>更多</span><img width="28px"src="../assets/images/more_btn.png">
          </div>
          <div class="maintain-box" v-if="currentTreeNode">
            <edit-trigger v-if="currentTreeNode.key==='entry'" :triggers="scenarioDetailJson.entry.triggers"
            @change="handleDetailJsonChange"></edit-trigger>
            <edit-bot-question v-else-if="currentTreeNode.nodeType==='QUESTION'"
            :BOTQuestion="currentBotQuestion" :nodeList="scenarioDetailJson.nodeList"
            @change="handleDetailJsonChange" @titleChanged="handleBotTitleChanged"
            @addSubNode="handleAddSubAnswerNode" @removeSubNode="handleRemoveAnswerNode"
            @deleteNode="handleDeleteQNode"></edit-bot-question>
            <edit-bot-answer v-else :BOTAnswer="currentBotAnswer" @change="handleDetailJsonChange" @createRelevantNode="initializeCreateDlg"
            :nodeList="scenarioDetailJson.nodeList" :nodeMap="scenarioDetailMap" @updateNavigation="handleUpdateNavigation"
            @addNavigation="handleAddNavigation" @deleteNavigation="handleDeleteNavigation"></edit-bot-answer>
          </div>
        </div>
      </transition>
    </div>
    <base-loading class="loading-indicator" v-show="isLoading"></base-loading>
    <el-dialog :visible.sync="isCreateDlgOpen" :show-close="false" title="创建新问题" class="create-scenario-dialog">
      <div class="dlg-content">
        <div>
          <i class="el-icon-star-on"></i>
          <span>关联问名称</span>
          <el-input v-model="nameOfNewRelevantNode"></el-input>
        </div>
      </div>
      <span slot="footer">
        <button class="btn-white-gray btn-small" @click="isCreateDlgOpen=false">取消</button>
        <button class="btn-dark-blue btn-small" @click="handlCreateRelevantNode">确定创建</button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import api from '../js/taskengineapi';
import { saveAs } from '../js/FileSaver';
import TDEGlobal from '../js/TDEGlobal';
import TDETreeChart from './TDETreeChart';
import EditTrigger from './EditTrigger';
import EditBotQuestion from './EditBotQuestion';
import EditBotAnswer from './EditBotAnswer';


export default {
  props: {
    scenarioId: {
      type: String,
      default: '',
    },
    scenarioName: {
      type: String,
      default: '',
    },
    scenarioEnabled: {
      type: Boolean,
      default: false,
    },
  },
  created() {
    this.getScenarioDetailJson(this.scenarioId);
  },
  data() {
    return {
      isLoading: false,
      // 后台返回的Scenario数据
      scenarioDetailJson: {},
      scenarioDetailMap: {},
      nodeTreeData: [],
      // 右边维护框
      isEditingTaskName: false,
      showInformationPanel: true,
      currentTreeNode: {},
      currentBotQuestion: {},
      currentBotAnswer: {},
      // 创建新问题对话框
      isCreateDlgOpen: false,
      nameOfNewRelevantNode: '',
      currentBotAnswer: {},
      currentBotNav: {},
    };
  },
  methods: {
    // 修改场景名称
    handleChangeTaskName() {
      console.log('~~~~~~~~handleChangeTaskName')
    },
    handleDetailJsonChange() {
      console.log('~~~~~~~~handleDetailJsonChange');
    },
    // 获取某个场景的详细信息
    getScenarioDetailJson(scenarioId) {
      this.isLoading = true;
      api.axiosGetScenarioDetail.call(this, scenarioId, (detail) => {
        this.scenarioDetailJson = detail;
        this.generateTreeChart(this.scenarioDetailJson);
        this.isLoading = false;
      });
    },
    // 生成图表的数据, 存入【scenarioNodesMap】和【nodeTreeData】中
    generateTreeChart(detailJson) {
      const res = [];
      const { entry } = detailJson;
      if (entry) {
        res.push({
          key: 'entry',
          parent: 'RobotQRoot',
          nodeType: 'QUESTION',
          navigationType: '',
          nodeName: '场景入口',
          isleaf: false,
        });
      }
      const { nodeList } = detailJson;
      // 创建node_id -> node_value的map
      if (nodeList instanceof Array) {
        nodeList.forEach((item) => {
          this.scenarioDetailMap[item.nodeId] = item;
        });
      }
      nodeList.forEach((item) => {
        if (item.isRelevant === false && item.nodeId !== 'exit') {
          const parentId = item.isGlobal ? 'GeneralQRoot' : 'RobotQRoot';
          this.genereateTreeNode(parentId, null, item.nodeId, null, false, res, '');
        }
      });
      this.nodeTreeData = res;
    },
    genereateTreeNode(parentId, parentType, nodeId, nodePresetText, isNodeExisted, targetArray, navId) {
      const nodeData = this.scenarioDetailMap[nodeId];
      if (!nodeData) {
        return;
      }
      const treeNode = {
        key: nodeId,
        parent: parentId,
        nodeType: 'QUESTION',
        navigationType: 'green', // '', 'green', 'red', 'blue';
        nodeName: nodeData.title,
        isleaf: false,
        data: nodeData
      };

      if (`${nodeId}-${parentType}` === parentId) {
        // 当前结点是parent结点，如：前往[重复问]|[解析失败]等话术
        treeNode.key = `${parentId}-${navId}`;
        treeNode.isleaf = true;
        treeNode.nodeName = `[${nodePresetText}]`;
        if (nodePresetText === '解析失败') {
          treeNode.navigationType = 'red';
        } else {
          treeNode.navigationType = 'blue';
        }
      } else if (nodeData.isRelevant === false) {
        // 当前结点是一级结点，非关联结点
        if (parentId === 'GeneralQRoot' || parentId === 'RobotQRoot') {
          // 添加一级结点，如[确认本人]或[退出对话]
          treeNode.navigationType = '';
        } else {
          // 前往一级结点，如：前往[是否方便]
          treeNode.key = `${parentId}-${navId}`;
          treeNode.isleaf = true;
          if (nodeId !== 'exit') {
            treeNode.nodeName = `[${treeNode.nodeName}]`;
          } 
          treeNode.navigationType = 'green';
        }
      } else if (nodeData.isRelevant) {
        treeNode.navigationType = 'green';
        // 关联问是否被添加到关联的问题下
        if (nodeData.relevantParent && `${nodeData.relevantParent.nodeId}-${nodeData.relevantParent.answerType}` === parentId) {
          treeNode.isleaf = false;
        } else {
          // 当前是关联结点,如：前往提供新号码，Hover可展开
          treeNode.isleaf = true;
        }
      }
      if (nodeId === 'exit') {
        treeNode.navigationType = 'red';
        treeNode.nodeName = treeNode.nodeName;
      }

      // if (!parentType) {
      //   treeNode.navigationType = '';
      // } else if (parentType === '告知' || parentType === '文本') {
      //   treeNode.navigationType = 'green';
      // } else if (parentType === '重复' || parentType === '提问') {
      //   treeNode.navigationType = 'blue';
      // } else {
      //   treeNode.navigationType = 'red';
      // }
      // 添加问题结点
      targetArray.push(treeNode);

      if (treeNode.isleaf) {
        return;
      }
      if (nodeData.answerTypes instanceof Array) {
        nodeData.answerTypes.forEach((item) => {
          if (!item.enabled) {
            return;
          }
          // 添加当前回答类型结点
          const answerNode = {
            key: `${nodeId}-${item.type}`,
            parent: nodeId,
            nodeType: 'ANSWERTYPE',
            navigationType: '', // '', 'green', 'red', 'blue';
            nodeName: item.type,
            isleaf: false,
            data: item
          };
          targetArray.push(answerNode);
          if (item.navigations instanceof Array) {
            item.navigations.forEach((nav) => {
              const toNodeId = nav.action && nav.action.navigateTo && nav.action.navigateTo.nodeId;
              if (toNodeId) {
                const id = `${nodeId}-${item.type}`;
                const pre = nav.action.navigateTo.nodePresetTexts;
                const exist = nav.action.navigateTo.alreadyExist;
                this.genereateTreeNode(id, item.type, toNodeId, pre, exist, targetArray, nav.navId);
              }
            });
          }
        });
      }
    },
    // 添加关联问
    handleAddRelevantQuestion(parentId, parentText, nodeId, nodeTitle) {
      const parent = this.scenarioDetailMap[parentId];
      if (!parent || !parent.nodeId) {
        return;
      }
      let newBot = TDEGlobal.GetBotQTemplate();
      // Object.assign(newBot, TDEGlobal.BotQTemplate);
      newBot.nodeId = nodeId;
      newBot.title = nodeTitle;
      newBot.isGlobal = parent.isGlobal;
      newBot.isRelevant = true;
      newBot.relevantParent = {
        nodeId: parentId,
        answerType: parentText,
      };
      this.scenarioDetailMap[nodeId] = newBot;
      this.scenarioDetailJson.nodeList.push(newBot);
    },
    expandInformationPanel() {
      this.showInformationPanel = false;
    },
    handleSelectNode(data) {
      this.showInformationPanel = true;
      this.currentTreeNode = data;
      if (data.nodeType === 'QUESTION') {
        this.currentBotQuestion = this.scenarioDetailMap[data.key];
      } else {
        const questionId = data.parent;
        const answerType = data.nodeName;
        const questionNode = this.scenarioDetailMap[questionId];
        if (!questionNode || !questionNode.answerTypes instanceof Array ) {
          return;
        }
        questionNode.answerTypes.forEach((item) => {
          if (item.type === answerType) {
            this.currentBotAnswer = item;
          }
        });
      }
    },
    /*
    * Node-Tree 返回事件处理
    */
    // 添加一级BOT问
    handleAddBotQuestion(nodeTitle, isGlobal, isRelevant, relevantParent) {
      // 添加问题结点
      const nodeId = Math.random().toString(36).substr(2);
      let nodeData = TDEGlobal.GetBotQTemplate();
      // Object.assign(nodeData, TDEGlobal.BotQTemplate);
      nodeData.nodeId = nodeId;
      nodeData.title = nodeTitle;
      nodeData.isGlobal = isGlobal;
      nodeData.isRelevant = isRelevant;
      nodeData.relevantParent = relevantParent;

      // relevantParent: {
      //   // nodeId: '84212722430001',
      //   // answerType: '文本',
      // },
      let parentId = '';
      let color = '';
      if (relevantParent) {
        parentId = `${relevantParent.nodeId}-${relevantParent.answerType}`;
        color = 'green';
      }
      // 更新数据
      this.scenarioDetailMap[nodeId] = nodeData;
      this.scenarioDetailJson.nodeList.push(nodeData);
      this.$refs.tasksTreeDiagram.apiAddBotQNode(nodeData.nodeId, nodeData.title, parentId, color, nodeData.isGlobal, false);
      // 添加默认开启的回答类型结点
      if (nodeData.answerTypes instanceof Array) {
        nodeData.answerTypes.forEach((item) => {
          if (item.enabled) {
            this.$refs.tasksTreeDiagram.apiAddAnswerNode(nodeId, item.type);
          }
        })
      }
      return nodeId;
    },
    // 创建一级BOT问
    handleCreateBotQuestion(title) {
      // 添加问题结;
      if (!title || title==='+新增BOT问') {
        return;
      }
      this.handleAddBotQuestion(title, false, false, null);
    },
    // 创建一级BOT情景问
    handleCreateGenQuestion(title) {
      if (!title || title==='+新增情景') {
        return;
      }
      this.handleAddBotQuestion(title, true, false, null);
    },
    // 添加关联BOT问
    // 打开创建对话框，初始化数据
    initializeCreateDlg(botAnswer, botNav) {
      this.currentBotAnswer = botAnswer;
      this.currentBotNav = botNav;
      this.isCreateDlgOpen = true;
    },
    handlCreateRelevantNode() {
      this.isCreateDlgOpen = false;
      if (!this.nameOfNewRelevantNode) {
        return;
      }
      const index = this.currentTreeNode.key.indexOf(this.currentBotAnswer.type);
      if (index < 1) {
        return;
      }
      const parentId = this.currentTreeNode.key.substring(0, index-1);
      const parentNode = this.scenarioDetailMap[parentId];
      const relevantParent = {
        nodeId: parentId,
        answerType: this.currentBotAnswer.type,
      };
      const newNodeId = this.handleAddBotQuestion(this.nameOfNewRelevantNode, parentNode.isGlobal, true, relevantParent);
      this.currentBotNav.action.navigateTo = {
        nodeId: newNodeId,
        nodePresetTexts: '预设问题'
      }
    },
    /*
    * BOT问维护页面事件处理
    */
    // 修改BOT问标题
    handleBotTitleChanged(nodeId, newTitle) {
      this.$refs.tasksTreeDiagram.apiChangeNodeTitle(newTitle);
    },
    // 增加BOT问的回答类型
    handleAddSubAnswerNode(questionId, answerTypeName) {
      console.log(`add answer node = ${answerTypeName}`);
      // 在node-tree中添加
      this.$refs.tasksTreeDiagram.apiAddAnswerNode(questionId, answerTypeName);
    },
    // 删除BOT问的回答类型
    handleRemoveAnswerNode(questionId, answerTypeName) {
      console.log(`remove answer node = ${answerTypeName}`);
      // 1. 从node-tree中删除
      this.$refs.tasksTreeDiagram.apiRemoveAnswerNode(questionId, answerTypeName);
    },
    // 返回到List页面
    handleNavigateBack() {
      this.$emit('back');
    },
    // 导出场景Json文件
    handleExportTaskJson() {
      console.log('handleExportTaskJson');
      const content = JSON.stringify(this.scenarioDetailJson);
      const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
      saveAs(blob, '招商信诺回访.json');
    },
    // 删除场景
    handleDeleteQNode(nodeId) {
      const nodeJson = this.scenarioDetailMap[nodeId];
      // 从nodeTree中删除
      this.$refs.tasksTreeDiagram.apiRemoveBotQNode(nodeId);
      if (nodeJson.answerTypes instanceof Array) {
        nodeJson.answerTypes.forEach((item) => {
          this.$refs.tasksTreeDiagram.apiRemoveAnswerNode(nodeId, item.type);
        });
      }
      // 从json & map 中删除
      this.scenarioDetailJson.nodeList.forEach((item, index) => {
        if (item.nodeId === nodeId) {
          this.scenarioDetailJson.nodeList.splice(index, 1);
          // break;
        }
      })
      this.scenarioDetailMap[nodeId] = null;
    },
    // 回答类型 - 新增连线
    handleAddNavigation(answer, navId, nodeId, pretext) {
      const parentId = `${this.currentTreeNode.key}`;
      const parentType = answer.type;
      const isGlobal = answer.isGlobal;
      
      let nodeName = `[${this.scenarioDetailMap[nodeId].title}]`;
      let color = 'green';
      if (nodeId === 'exit') {
        nodeName = this.scenarioDetailMap[nodeId].title
        color = 'red';
      } else if (parentId === `${nodeId}-${answer.type}`) {
         nodeName = `[${pretext}]`;
        if (pretext === '解析失败') {
          color = 'red';
        } else {
          color = 'blue';
        }
      }

      this.$refs.tasksTreeDiagram.apiAddBotQNode(`${parentId}-${navId}`, nodeName, this.currentTreeNode.key, color, isGlobal, true);
    },
    handleDeleteNavigation(answer, navId, nodeId, pretext) {
      const parentId = `${this.currentTreeNode.key}`;
      console.log(`handleDeleteNavigation     ---     ${parentId}-${navId}`);
      this.$refs.tasksTreeDiagram.apiRemoveBotQNode(`${parentId}-${navId}`);
    },
    handleUpdateNavigation(answer, navId, oldNodeId, nodeId, pretext) {
      const parentId = `${this.currentTreeNode.key}`;

      let nodeName = `[${this.scenarioDetailMap[nodeId].title}]`;
      let color = 'green';
      if (nodeId === 'exit') {
        nodeName = this.scenarioDetailMap[nodeId].title
        color = 'red';
      } else if (parentId === `${nodeId}-${answer.type}`) {
         nodeName = `[${pretext}]`;
        if (pretext === '解析失败') {
          color = 'red';
        } else {
          color = 'blue';
        }
      }
      this.$refs.tasksTreeDiagram.apiChangeNodeTitle2(`${parentId}-${navId}`, nodeName);
    },
  },
  components: {
    TDETreeChart,
    EditTrigger,
    EditBotQuestion,
    EditBotAnswer,
  },
};
</script>

<style lang="scss" scoped>
@import "../assets/scss/style";
.scenarios-detail-wrapper{
  width: 100%;
  height: 100%;
  .loading-indicator{
    background: rgba(255, 255, 255, 0.5) !important;
  }
  .scenarios-detail-content{
    width: 100%;
    height: 100%;
    display: flex;
    .chart-box{
      flex: 1;
      height: 100%;
      position: relative;
      .hide-digram{
        width: 100%;
        height: 17px;
        position: absolute;
        top: -17px;
        left: 0;
        background: #EEEEEE;
        z-index: 9;
      }
      .header{
        width: 100%;
        height: 50px;
        margin-bottom: 10px;
        background: white;
        position: absolute;
        top: 0;
        left: 0;
        z-index: 10;
        h1{
          margin-left: 20px;
          line-height: 50px;
          height:22px;
          width: 190px;
          font-size:16px;
          font-family:PingFangSC-Regular;
          font-weight:400;
          color:rgba(51,51,51,1);
          display: inline-block;
        }
        div{
          display: inline-block;
          margin-left: 20px;
          margin-right: 10px;
          vertical-align: middle;
          margin-top: -3px;
        }
        span{
          width:57px;
          height:22px;
          font-size:14px;
          font-family:PingFangHK-Regular;
          font-weight:400;
          color: #666666;
          line-height:22px;
          &.subtitle{
            color: #999999;
          }
        }
        .bot-question-box{
          width:34px;
          height:22px;
          background:rgba(219,228,236,1);
          border-radius:11px;
        }
        .user-box{
          width:34px;
          height:22px;
          background:rgba(231,236,240,1);
          box-shadow:4px 0px 0px 0px rgba(196,206,216,1);
          border-radius:2px;
          border:1px solid rgba(196,206,216,1);
        }
        .execution-box{
          width:10px;
          height:10px;
          background:rgba(61,128,255,1);
          border-radius:5px;
        }
      }
      .add-button{
        position: absolute;
        top: 50px;
        left: 0px;
        z-index: 30;
        width:168px;
        height:34px;
        border-radius:20px;
        background: white;
        margin-left: 10px;
        border:1px dotted rgba(219,219,219,1);
        display: inline-block;
        line-height: 34px;
        text-align: center;
        &:hover{
          color: #1875F0;
          border: 1px dotted #B1CCFF;
        }
      }
      .diagram-box{
        height: 100%;
        width: 100%;
      }
    }
    .information-box{
      position: absolute;
      top: 0;
      right: 0;
      width:350px;
      height: 100%;
      background:rgba(252,252,252,1);
      box-shadow:1px 1px 1px 1px rgba(233,233,233,1);
      z-index: 10;
      overflow: hidden;
      display: flex;
      flex-direction: column;
      .header{
        height: 50px;
        padding: 0px 20px;
        background-color: rgba(247,247,247,1);
        box-shadow:0px 1px 0px 0px rgba(233,233,233,1);
        display: flex;
        align-items: center;
        .back-btn{
          width: 8px;
          margin-right: 10px;
          cursor: pointer;
        }
        .task-name{
          font-size:16px;
          font-weight:500;
          color: #333333;
          line-height:50px;
          flex: 1;
        }
        .edit-btn{
          margin-left: 10px;
          width: 24px;
          height: 24px;
          margin-right: 20px;
          cursor: pointer;
        }
        .expand-btn{
          height: 30px;
          line-height: 30px;
          box-shadow:-1px 0px 0px 0px rgba(233,233,233,1);
          >div{
            cursor: pointer;
            margin-left: 20px;
            img{
              width: 14px;
            }
          }
        }
      }
      .operations{
        height: 60px;
        background-color: #FFFFFF;
        align-items: center;
        padding: 0px 20px;
        display: flex;
        box-shadow:0px -1px 0px 0px rgba(233,233,233,1);
        >span{
          font-size:14px;  
          color: #333333;
          margin-right: 10px;
          margin-left: 30px;
          &:first-child{
            margin-left: 0px;
          }
        }
        el-switch, img{
          cursor: pointer;
        }
      }
      .maintain-box{
        box-shadow:0px -1px 0px 0px rgba(233,233,233,1);
        width: 100%;
        flex: 1;
        overflow: auto;
      }
    }
  }
  .create-scenario-dialog{
    /deep/ .el-dialog{
      width: 500px;
    }
    /deep/ .el-dialog__header{
      box-shadow: 0px 1px 0px 0px rgba(233,233,233,1);
    }
    /deep/ .el-dialog__body{
      padding: 0px !important;
      box-shadow: 0px 1px 0px 0px rgba(233,233,233,1);
    }
    .dlg-content{
      padding: 50px 20px;
      >div{
        display: flex;
        >i{
          width: 12px;
          line-height: 32px;
          font-size: 8px;
          color: #F25C62;
          vertical-align: top;
        }
        span{
          margin-left: 5px;
          // width: 56px;
          height: 32px;
          line-height: 32px;
          margin-right: 20px;
        }
        /deep/ .el-input{
          flex: 1;
          height: 32px;
          line-height: 32px;
          input{
            height: 32px;
            line-height: 32px;
          }
        }
      }
    }
  }
}
.slide-fade-enter-active {
  transition: all .3s ease;
}
.slide-fade-leave-active {
  transition: all .5s cubic-bezier(1.0, 0.5, 0.8, 1.0);
}
.slide-fade-enter, .slide-fade-leave-to
/* .slide-fade-leave-active for below version 2.1.8 */ {
  transform: translateX(350px);
  opacity: 0;
}
</style>
