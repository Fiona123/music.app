<template>
  <div class="edit-question-wrapper">
    <div class="header">
      <span>BOT问-待收集信息</span>
      <img @click="handleClickDeleteBtn" src="../assets/images/delete_b.png">
    </div>
    <div class="title-box">
      <span>图示标题</span>
      <el-input v-model="BOTQuestion.title" class="tde-el-input" @change="handleTitleChanged"></el-input>
    </div>
    <div class="pre-texts-box">
      <div class="pre-text" v-for="(item, index) in BOTQuestion.presetTexts">
        <div class="text-title-wrapper">
          <div class="text-title-box" v-if="isSystemType(item.title)">
            <span class="title">{{item.title}}</span>
            <el-dropdown v-if="index===0" class="tde-el-dropdown" @command="handleAddPreText">
              <span class="el-dropdown-link">
                新增自定义<i class="el-icon-arrow-down el-icon--right"></i>
              </span>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item v-for="(item, key) in PretextsType" :key="key" :command="item">{{item}}</el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
            <img src="../assets/images/delete_s.png" v-else @click="handleDeletePretext(item)">
          </div>
          <div class="text-title-box" v-else>
            <el-input v-model="item.title" class="tde-el-input title" @change="handleSaveChange"></el-input>
            <img src="../assets/images/delete_s.png" @click="handleDeletePretext(item)">
          </div>
        </div>
        <div class="text-content-wrapper">
          <el-input v-model="item.value" class="tde-el-input" v-if="isSystemType(item.  title)" @change="handleSaveChange"></el-input>
          <el-input class="tde-el-textarea" type="textarea" :rows="2" placeholder="请输入内容"
          v-model="item.value" v-else @change="handleSaveChange"></el-input>
        </div>
        <div class="additional-info-box" v-show="item.count!==undefined">
          <span class="label-title">{{item.title}}</span>
          <el-input-number v-model="item.count" controls-position="right" class="tde-el-input-number"
          @change="handleSaveChange" :min="1" :max="1000"></el-input-number>
          <span>次, 则前往</span>
          <el-select v-model="item.toNodeId" class="tde-el-select" @change="handleSaveChange">
            <el-option v-for="item in nodeList" :key="item.id" :label="item.title" :value="item.title"></el-option>
          </el-select>
        </div>
      </div>
    </div>
    <div class="parser-box">
      <div class="parser-header">
        <span>解析器选择</span>
        <span>设置规则</span>
      </div>
      <el-select v-model="BOTQuestion.parserId" placeholder="请选择" class="tde-el-select select-parser" @change="handleSaveChange">
        <el-option v-for="item in parserList" :key="item.parserId" :label="item.parserName" :value="item.parserId"></el-option>
      </el-select>
    </div>
    <div class="answer-type-box">
      <p>用户回答类型选择</p>
      <el-checkbox-group v-model="checkedAnswerTypes" @change="handleAnswerTypeChange">
        <div v-for="item in BOTQuestion.answerTypes" class="checkbox-div">
          <el-checkbox :label="item.type" :key="item.type">{{item.type}}</el-checkbox>
        </div>
      </el-checkbox-group>
    </div>
    <div class="general-answer-type-box">
      <p>通用回答类型</p>
      <div v-for="item in BOTQuestion.generalAnswerType">
        <el-checkbox disabled v-model="item.enabled" class="tde-checkbox" @click="handleAnswerTypeChange">{{item.type}}</el-checkbox>
      </div>
    </div>
  </div>
</template>

<script>
import TDEGlobal from '../js/TDEGlobal';
import api from '../js/taskengineapi';

export default {
  props: {
    // 当前编辑BOT问的信息
    BOTQuestion: {
      type: Object,
      // default() {
      //   return {
      //     "nodeId": "84212722430001"
      //     title: '确认本人',
      //     presetTexts: [
      //       {
      //         title: '预设问题', value: '请问是name本人吗？', type: 'system',
      //       },
      //       {
      //         title: '自定义话术1', value: '自定义话术1文本', type: 'user',
      //       },
      //       {
      //         title: '重复问题', value: '请问是name本人吗？', count: 5, toNodeId: '0', type: 'system',
      //       },
      //       {
      //         title: '解析失败', value: '请问是name本人吗？', count: 10, toNodeId: '1', type: 'system',
      //       },
      //       {
      //         title: '延续话术', value: '请问是name本人吗', count: 8, toNodeId: '2', type: 'system',
      //       },
      //     ],
      //     parserId: '1',
      //     answerTypes: [
      //       { type: '告知', enabled: true },
      //       { type: '回问', enabled: true },
      //       { type: '不知道', enabled: true },
      //       { type: '催促', enabled: true },
      //       { type: '未能获取答案', enabled: false },
      //       { type: '全选', enabled: false },
      //       { type: '不确定', enabled: true },
      //       { type: '随意', enabled: true },
      //       { type: '拒绝告知', enabled: true },
      //       { type: '全不选', enabled: false },
      //       { type: '回避', enabled: true },
      //       { type: '回问', enabled: true },
      //     ],
      //     generalAnswerType: [
      //       { type: '转人工', enabled: true },
      //       { type: '继续', enabled: true },
      //       { type: '命令重复', enabled: true },
      //       { type: '寒暄', enabled: true },
      //       { type: '告知等待', enabled: false },
      //       { type: '告别', enabled: false },
      //       { type: '退出', enabled: true },
      //     ],
      //   };
      // },
    },
    // 场景所有BOT问列表
    nodeList: {
      type: Array,
    },
  },
  created() {
    this.initialize();
  },
  watch: {
    BOTQuestion(newVal) {
      this.initialize();
    },
  },
  data() {
    return {
      // 当前选中的回答类型
      checkedAnswerTypes: [],
      // 解析器列表
      parserList: [],
    };
  },
  computed: {
    PretextsType() {
      return TDEGlobal.SystemPresetTexts.concat('自定义话术') || [];
    }
  },
  methods: {
    initialize() {
      // 初始化回答类型checkbox 列表
      this.checkedAnswerTypes = [];
      if (this.BOTQuestion.answerTypes instanceof Array) {
        this.BOTQuestion.answerTypes.forEach((item) => {
          if (item.enabled) {
            this.checkedAnswerTypes.push(item.type);
          }
        })
      }
      api.axiosGetParserList.call(this, 'appId', (list) => {
        this.parserList = list;
      })
    },
    // 新增预设问题
    handleAddPreText(typeOfText) {
      console.log(typeOfText)
      let text = { title: typeOfText, value: '', type: 'system' };
      if (typeOfText === '自定义话术') {
        text.title = '';
        text.type = 'user';
      }
      if (typeOfText !== '预设问题' && typeOfText !== '自定义话术') {
        text.count = 0;
        text.toNodeId = '';
        text.type = 'system';
      }
      this.BOTQuestion.presetTexts.push(text);
    },
    // 新增预设问题
    handleDeletePretext(item) {
      const index = this.BOTQuestion.presetTexts.indexOf(item);
      this.BOTQuestion.presetTexts.splice(index, 1);
    },
    handleSaveChange() {
      this.$emit('change');
    },
    handleTitleChanged() {
      this.$emit('change');
      this.$emit('titleChanged', this.BOTQuestion.nodeId, this.BOTQuestion.title);
    },
    handleAnswerTypeChange(checkedAnswerTypes) {
      this.BOTQuestion.answerTypes.forEach((item) => {
        const checkedNow = checkedAnswerTypes.indexOf(item.type) !== -1;
        const checkedBefore = item.enabled;
        if (checkedNow === checkedBefore) {
          return;
        } else if (checkedNow) {
          // 新增回答类型
          this.$emit('addSubNode', this.BOTQuestion.nodeId, item.type);
        } else {
          // 删除回答类型
          this.$emit('removeSubNode', this.BOTQuestion.nodeId, item.type);
        }
        item.enabled = checkedNow;
      });
    },
    handleClickDeleteBtn() {
      this.$emit('deleteNode', this.BOTQuestion.nodeId);
    },
    isSystemType(title) {
      return TDEGlobal.SystemPresetTexts.indexOf(title) !== -1;
    },
  },
};
</script>

<style lang="scss" scoped>
@import "../assets/scss/style";
.edit-question-wrapper{
  .header{
    height:50px;
    background:rgba(247,247,247,1);
    box-shadow:0px 1px 0px 0px rgba(233,233,233,1);
    display: flex;
    align-items: center;
    padding: 0px 20px;
    span{
      font-size: 16px;
      font-weight: 500;
      color: #333333;
      flex: 1;
    }
    img{
      width: 24px;
      cursor: pointer;
    }
  }
  .title-box{
    box-shadow:0px 1px 0px 0px rgba(233,233,233,1);
    padding: 10px 20px 20px 20px;
    span{
      width:48px;
      height:20px;
      font-size:12px;
      color: #999999;
      line-height:20px;
      margin-bottom: 4px;
      display: inline-block;
    }
  }
  .pre-texts-box{
    box-shadow:0px 1px 0px 0px rgba(233,233,233,1);
    padding: 0px 20px 10px 20px;
    .pre-text{
      margin-top: 10px;
      .text-title-box{
        margin-bottom: 4px;
        display: flex;
        align-items: center;
        span{
          height:20px;
          font-size:12px;
          line-height:20px;
        }
        .title{
          margin-right: 5px;
          color: #999999;
          flex: 1;
        }
        img{
          width: 10px;
          height: 12px;
          margin-left: 8px;
          cursor: pointer;
        }
      }
      .additional-info-box{
        display: flex;
        align-items: center;
        margin-top: 10px;
        .label-title{
          width: 50px;
          overflow: hidden;
          line-height: 20px;
          height: 20px;
        }
        >span{
          color: #666666;
          margin-right: 5px;
        }
        .el-input-number{
          width: 52px;
          margin-right: 5px;
        }
        .el-select{
          width: 135px;
          flex: 1;
        }
      }
    }
  }
  .parser-box{
    box-shadow:0px 1px 0px 0px rgba(233,233,233,1);
    padding: 10px 20px 20px 20px;
    .parser-header{
      margin-bottom: 4px;
      display: flex;
      span{
        height:20px;
        font-size:12px;  
        line-height:20px;
        &:first-child{
          color: #999999;
          flex: 1;
        }
        &:last-child{
          color: #333333;
          cursor: pointer;
        }
      }
    }
    .select-parser{
      height: 28px;
      width: 100%;
    }
  }
  .answer-type-box, .general-answer-type-box{
    margin: 10px 20px 20px 20px;
    >p{
      width: 100%;
      font-size: 12px;
      color: #999999;
      display: inline-block;
      line-height: 20px;
      height: 20px;
    }
    >div{
      width: 50%;
      margin-top: 10px;
      display: inline-block;
    }
    .el-checkbox-group{
      width: 100%;
      margin-top: 0px;
      >div{
        width: 50%;
        margin-top: 10px;
        display: inline-block;
      }
    }
  }
}
</style>
