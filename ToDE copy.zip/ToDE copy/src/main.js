// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue';
import App from './App';
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
/* eslint-disable no-new */
import '@/assets/scss/index.scss'
import axiosPlugin from '@/js/api'


Vue.config.productionTip = false;
Vue.use(ElementUI)
Vue.use(axiosPlugin)

/* eslint-disable no-new */
new Vue({
  el: '#app',
  components: { App },
  template: '<App/>',
});
